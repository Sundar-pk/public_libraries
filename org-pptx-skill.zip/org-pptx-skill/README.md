# Org Brand PPTX Skill

Standardizes every PowerPoint deck built with Claude across the company: same green
(`#00915A`) on white, same Calibri/Arial hierarchy (18/16/14/12pt), same
`Company Name | Presentation Title` header on every slide — no matter who on the team
asks Claude to build it.

## What's in this package

```
org-pptx-skill/
├── SKILL.md                     ← the skill itself (what Claude reads)
├── README.md                    ← this file
└── reference/
    └── brand-tokens.json        ← machine-readable brand constants
```

## How it works

Claude Skills are folders of instructions Claude reads automatically before doing
certain kinds of work — in this case, before building any `.pptx` file. You don't
run this skill yourself; you install it once, and Claude applies it silently every
time someone on the team asks for a deck.

`SKILL.md` locks in the brand rules (color, font, sizing, header format) and a short
clarification workflow. `brand-tokens.json` holds the actual hex codes and sizes as
data, so if the brand ever changes, one edit updates the standard everywhere instead
of hunting through prose.

## Installation

**Claude.ai (Team / Enterprise workspaces):**
1. Go to Settings → Capabilities → Skills (or ask your workspace admin — skill upload
   location depends on your plan).
2. Upload the `org-pptx-skill` folder (or a zip of it).
3. Enable it for the workspace so it's on by default for all members.

**Claude Code / API workflows:**
Place the folder at the path your setup scans for skills (commonly
`.claude/skills/org-pptx-skill/` in a repo, or your configured skills directory) so
it's picked up automatically.

If your organization's Claude setup differs, check `docs.claude.com` or your
workspace admin for the current skill-installation path — this can change between
plans and product updates.

## How staff should use it

Nothing new to learn. Employees just ask Claude for a deck the way they always have:

> "Build me a slide deck on our Q3 roadmap"
> "Turn this doc into a presentation for the client kickoff"
> "Make a pptx summarizing these notes for the exec review"

Claude will:
1. Read whatever content is provided (pasted text, an uploaded doc, notes).
2. Ask a short round of clarifying questions **only** for things the brand doesn't
   already fix — company name (if not obvious), presentation title, audience, and
   rough length. It will **not** ask about color, font, or sizing — those are locked.
3. Build the deck in brand: `#00915A` on white, Calibri/Arial, the 18/16/14/12pt
   hierarchy, and the standard header/footer on every slide.
4. Run a QA pass (content, file validity, and a brand-compliance checklist) before
   handing back the file.

## What "standard" means in practice

| Element | Locked value |
|---|---|
| Background | White (`FFFFFF`), every slide |
| Primary color | `#00915A` |
| Font | Calibri (Arial fallback) |
| Font sizes | 18pt title / 16pt section head / 14pt body / 12pt caption |
| Header | `Company Name \| Presentation Title`, every slide, top-left |
| Footer | Page number (+ optional confidentiality label) |

The only sanctioned exception is a 32pt title on the cover slide only — everything
else holds the four-size scale.

## Updating the brand

If the palette, font, or sizes ever change:
1. Edit `reference/brand-tokens.json` — this is the single source of truth.
2. Skim `SKILL.md`'s tables to make sure the prose still matches the JSON (they're
   meant to stay in sync; the JSON is what Claude actually reads before generating
   code, the prose is what keeps a human reviewer oriented).
3. Re-upload/re-sync the skill for the workspace.

No need to chase down every employee's past prompts or habits — the enforcement lives
in the skill, not in how people ask.

## Requesting an off-brand exception

For a genuinely personal or one-off deck where someone wants a different look, they
can say so explicitly (e.g. "build this deck without the company branding"). The
skill will confirm the opt-out rather than silently deviating, so brand drift stays
a deliberate choice, not a default.
