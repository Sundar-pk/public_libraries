---
name: org-brand-pptx
description: "Use this skill whenever a user asks Claude to build, draft, or generate a PowerPoint / slide deck / presentation for the organization — including requests like 'make me a deck on X', 'turn this into slides', 'build a presentation for the CIO review', or 'create a pptx'. This is the mandatory enterprise standard for all internal and client-facing decks: it fixes the brand palette (#00915A on white), typography (Calibri/Arial, 18/16/14/12pt hierarchy), and the 'Company Name | Presentation Title' header on every slide. Always apply this skill INSTEAD OF free-styling colors, fonts, or layout choices, even if the user doesn't mention branding. If the user explicitly asks for a different, non-brand look for a one-off/personal deck, confirm that they want to opt out of the standard before deviating."
license: Internal use — organization proprietary. Do not distribute outside the company.
---

# Enterprise PPTX Brand Standard

This skill exists so that **every deck built with Claude across the organization looks like
it came from the same design team** — regardless of which employee built it. It is a
brand-compliance layer on top of the general-purpose `pptx` skill (`/mnt/skills/public/pptx/SKILL.md`).
Read that skill too — it covers the pptxgenjs technical gotchas, validation, and QA process
this skill does not repeat. This skill only adds and enforces: **the brand constants, the
clarification workflow, and the review checklist.**

**Do not deviate from the values below.** They are not suggestions — they are the standard.
If a user asks for a different color, font, or layout for a company deck, tell them this
skill enforces the enterprise standard and ask if they specifically want an off-brand,
personal/one-off exception before proceeding differently.

## 1. Brand constants

All values are also machine-readable in `reference/brand-tokens.json` — read that file
before generating code so constants never get hand-typed or drift.

### Color

| Token | Hex | Use |
|---|---|---|
| Primary | `00915A` | Titles, key numbers/stats, active states, chart primary series, icon accents |
| Primary Dark | `006B43` | Hover/pressed states, gradients, secondary chart series |
| Primary Tint | `E6F5EE` | Card backgrounds, tinted panels, subtle section fills |
| Background | `FFFFFF` | Always the slide background. Never cream/beige/gray defaults. |
| Text Primary | `1A1A1A` | Body copy, titles — not pure black |
| Text Secondary | `5F6B67` | Captions, footers, source lines, muted labels |
| Divider | `E0E0E0` | Table borders, subtle separators only — never as a decorative accent stripe |

Never use `#` prefixes or 8-digit (alpha) hex values in pptxgenjs — see the base `pptx`
skill's gotchas. Never introduce a color outside this table without the user explicitly
requesting an exception.

### Typography

Font: **Calibri** (primary) with **Arial** as fallback. Set both on every text run so the
deck still resolves correctly on machines without Calibri:

```javascript
fontFace: "Calibri"   // pptxgenjs uses this as-is; PowerPoint falls back to Arial-family
                       // metrics automatically if Calibri is missing on the render machine
```

Four-level size hierarchy — **use these sizes only**, no in-between values:

| Level | Size | Weight | Color | Where |
|---|---|---|---|---|
| Slide Title | **18pt** | Bold | Text Primary | Top of every content slide |
| Section Head | **16pt** | Bold | Primary (`00915A`) | Sub-headers, callout labels, chart/table titles |
| Body | **14pt** | Regular | Text Primary | Bullets, paragraph text, table cells |
| Caption | **12pt** | Regular | Text Secondary | Footnotes, source lines, header/footer bar, page numbers |

**One deliberate exception:** the title slide's main title may run **32pt bold** for visual
impact — a full 18pt title reads weak as the very first thing the audience sees. Every
other slide holds the line at 18/16/14/12. Do not let this exception creep onto content
slides.

### Layout

- Canvas: `LAYOUT_WIDE` (13.333" × 7.5") — set `pres.layout` before adding slides, per the
  base pptx skill.
- Margins: 0.5" sides, 0.4" top, 0.35" bottom (the bottom margin is reserved for the footer).
- White background on every slide — no exceptions, no gradients, no photography-as-background
  unless the user supplies brand-approved imagery.

## 2. Mandatory header (every slide)

Every slide — including the title slide — carries a slim header bar at the top:

```
{Company Name}  |  {Presentation Title}
```

- 12pt Caption style, Text Secondary color, left-aligned, positioned inside the top margin.
- The separator is a pipe with a space on each side: `  |  `.
- Same text, verbatim, on every slide of the deck — this is what makes decks
  instantly recognizable as "ours" when skimmed in a folder or inbox.

Footer (bottom-right, same 12pt Caption style): page number, and an optional
confidentiality label (e.g. `Internal Use Only`) if the user requests one.

## 3. Workflow

### Step 1 — Get the content
Take whatever the user gives you: raw notes, a document, bullet points, a rough outline.
If they reference an uploaded file, read it before asking anything else — don't ask
questions you could answer yourself from what's already provided.

### Step 2 — Ask clarifying questions (required, keep it short)
Before generating anything, confirm the details that change the output. Don't ask about
things this skill already fixes (color, font, sizing — those are locked). Ask only:

1. **Company name** for the header — if not already established earlier in the
   conversation or visible in uploaded content, ask for it. Never leave the header
   as a generic placeholder like "Your Company Name" in a delivered file.
2. **Presentation title** for the header — if not obvious from the content.
3. **Audience / occasion** (e.g. "exec review," "client pitch," "team update") — this
   shapes tone and depth, not styling.
4. **Approximate length** — number of slides or sections, if the content doesn't make
   it obvious.
5. Anything genuinely ambiguous in the content itself (e.g. real figures vs. placeholder
   figures, whether a chart is wanted for a given data point).

Ask these together, in one pass — don't drip clarifying questions one at a time across
multiple turns. If the user has already answered a question earlier in the conversation,
don't ask it again.

### Step 3 — Build
Follow the base `pptx` skill's `pptxgenjs` process, applying the constants from Section 1
and the header from Section 2 to every slide. Practical notes specific to this brand:

- Define the brand constants once at the top of the script (color hexes, font names, the
  four type sizes) and reference them everywhere — never hardcode a hex or size inline.
  This is what makes the deck auditable against the standard.
- Build a small `addHeader(slide, companyName, deckTitle)` and `addFooter(slide, pageNum)`
  helper and call it for every slide, so the header/footer can never drift slide-to-slide.
- Vary layout (not styling) slide-to-slide per the base skill's design guidance — stat
  callouts, two-column comparisons, timelines, etc. The brand lock is on color/font/size,
  not on making every slide a title-and-bullets clone.
- Use Primary Tint (`E6F5EE`) for card/panel backgrounds when a slide needs visual
  separation — this is the brand-safe way to add contrast without introducing a new color.
- Charts: primary series in `00915A`, secondary in `006B43`, never default PowerPoint blue.

### Step 4 — QA (required, do not skip)
Run the base `pptx` skill's full QA process: content check (`markitdown`), file validation
(`scripts/office/validate.py`), and visual QA via rendered images. In addition, check
specifically for **brand compliance**:

- [ ] Every text run is Calibri (Arial fallback) — no stray theme fonts
- [ ] Every font size is exactly 18, 16, 14, 12, or the one approved 32pt cover exception
- [ ] Every color used traces back to the palette table — grep the generator script for
      `srgbClr`/hex literals outside the constants block
- [ ] Header text is identical, verbatim, on every slide
- [ ] Background is white on every slide
- [ ] No accent stripes, underlines under titles, or decorative bars (see base skill's
      "Don't" list — these read as AI-generated and are explicitly off-brand here too)

Only after this checklist passes should the file be presented to the user.

## 4. Reference

- `reference/brand-tokens.json` — machine-readable constants (colors, fonts, sizes, layout,
  header/footer format). Read this before writing the pptxgenjs script.
- Base technical skill: `/mnt/skills/public/pptx/SKILL.md` — pptxgenjs gotchas, chart
  configuration, template editing, validation, and the visual QA process. This skill does
  not duplicate that content; read both.
