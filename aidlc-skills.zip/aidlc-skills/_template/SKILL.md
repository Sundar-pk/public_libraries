---
name: <skill-name-in-kebab-case>
description: "<one sentence: what it does and when to use it>"
---

# <skill-name> (<ID>)

- Group: <factory or shared>
- Skill number: <ID>
- Type: Core | Adapter | Domain
- Status: draft | reviewed | released

## 1. Description
What the skill does, when it is used, and the human gate that applies.

## 2. Inputs and outputs
- Inputs:
- Outputs:

## 3. Tools and permissions
Tools, MCP operations and file access allowed. Anything not listed is denied.

## 4. Tech stack
Core, or the stack adapters it needs.

## 5. Dependencies
Other skills and platform services it relies on.

## 6. Templates
Artifact templates it fills in.

## 7. Validation
How the output is checked before the next step or gate.

## 8. Reuse and enhancement
How other factories or applications reuse it and how it improves over time.
