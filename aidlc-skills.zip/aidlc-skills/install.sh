#!/bin/sh
# Copies every skill into a flat folder: ./.opencode/skills/<skill-name>/SKILL.md
# Usage: sh install.sh [target-project-dir]
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
TARGET="${1:-.}/.opencode/skills"
mkdir -p "$TARGET"
for d in "$HERE"/skills/*/*/; do
  name="$(basename "$d")"
  mkdir -p "$TARGET/$name"
  cp "$d/SKILL.md" "$TARGET/$name/SKILL.md"
done
echo "Installed skills into $TARGET"
