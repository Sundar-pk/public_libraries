# AIDLC skills (draft v0.1)

342 skills in 10 groups, generated from the AIDLC Skill Catalogue. Each skill is a folder with a `SKILL.md`
in the 8-field format (description, inputs and outputs, tools and permissions, tech stack, dependencies,
templates, validation, reuse and enhancement).

| Group | Folder | Skills |
| --- | --- | --- |
| Shared skills (used by every factory) | `skills/00-shared` | 33 |
| xprs-ba / bdd-forge-ba: business analysis | `skills/01-xprs-ba` | 39 |
| xprs-sp: sprint planning and delivery management | `skills/02-xprs-sp` | 23 |
| xprs-arch: architecture, security design and test strategy | `skills/03-xprs-arch` | 35 |
| xprs-dev: analysis, TDD, implementation, review and merge request | `skills/04-xprs-dev` | 59 |
| xprs-qa: testing, defects and quality evidence | `skills/05-xprs-qa` | 37 |
| xprs-rel: security scanning, release preparation and deployment | `skills/06-xprs-rel` | 43 |
| xprs-ops: monitoring, incident, problem and support | `skills/07-xprs-ops` | 36 |
| xprs-mod: modernisation, technical debt and continuous improvement | `skills/08-xprs-mod` | 34 |
| Domain-specific skills (banking) | `skills/09-domain-banking` | 3 |
| Total | | 342 |

## Notes

- `skills/<group>/README.md` lists the skill numbers and descriptions for that group. `INDEX.csv` lists all of them.
- `_template/SKILL.md` is the blank skill template.
- SH-01, DV-01 and DV-07 already exist in the team's repository. Replace the generated files with the current ones.
- Inputs and outputs are specific to each skill. Tools, dependencies, templates and validation are written once per group
  and should be refined skill by skill during the build and feedback iterations. Output schemas are not yet defined.
- OpenCode looks for skills in `.opencode/skills/<name>/SKILL.md` (to confirm in the spike). `install.sh` copies every skill into
  one flat folder of that shape.
