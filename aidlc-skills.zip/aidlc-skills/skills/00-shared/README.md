# Shared skills (used by every factory)

33 skills.

| No | Skill | Description | Type |
| --- | --- | --- | --- |
| SH-01 | [jira-ticket-resolution](jira-ticket-resolution/SKILL.md) | Resolves a ticket ID to RESOLVED, NOT_FOUND or USER_SUPPLIED (exists today) | Core |
| SH-02 | [jira-ticket-read](jira-ticket-read/SKILL.md) | Reads fields, links, comments and attachments of a ticket within the factory allow-list | Core |
| SH-03 | [jira-ticket-update](jira-ticket-update/SKILL.md) | Adds comments, labels, status transitions and links as the agent | Core |
| SH-04 | [jira-ticket-create](jira-ticket-create/SKILL.md) | Creates epics, stories, tasks, bugs and sub-tasks from approved content | Core |
| SH-05 | [confluence-page-read](confluence-page-read/SKILL.md) | Reads linked pages, specs and standards | Core |
| SH-06 | [confluence-page-publish](confluence-page-publish/SKILL.md) | Publishes or updates a page from a template | Core |
| SH-07 | [repo-context-discovery](repo-context-discovery/SKILL.md) | Detects language, build tool, test framework, modules and conventions of the repository | Adapter |
| SH-08 | [application-profile-load](application-profile-load/SKILL.md) | Loads the application profile: stack, standards, owners, gates, tooling overrides | Core |
| SH-09 | [artifact-handoff-write](artifact-handoff-write/SKILL.md) | Writes an output artifact in its schema and registers it for the next agent | Core |
| SH-10 | [artifact-handoff-read](artifact-handoff-read/SKILL.md) | Reads and validates an input artifact against its schema | Core |
| SH-11 | [human-gate-request](human-gate-request/SKILL.md) | Pauses the run, presents the evidence and records approve, reject or change | Core |
| SH-12 | [clarification-question-builder](clarification-question-builder/SKILL.md) | Turns gaps into a short list of closed questions for the human | Core |
| SH-13 | [assumption-and-risk-log](assumption-and-risk-log/SKILL.md) | Records each assumption and risk with owner and a way to confirm it | Core |
| SH-14 | [traceability-link](traceability-link/SKILL.md) | Links requirement, story, design, code, test and release evidence by ID | Core |
| SH-15 | [git-branch-and-commit](git-branch-and-commit/SKILL.md) | Creates the branch and commits with the ticket ID in the agreed message format | Core |
| SH-16 | [merge-request-create](merge-request-create/SKILL.md) | Opens a merge request with description, evidence and reviewers | Core |
| SH-17 | [build-and-test-run](build-and-test-run/SKILL.md) | Runs build and unit tests through the stack adapter and returns a normalised result | Adapter |
| SH-18 | [run-summary-report](run-summary-report/SKILL.md) | Produces the end-of-run summary: what was done, evidence, open items | Core |
| SH-19 | [audit-trail-emit](audit-trail-emit/SKILL.md) | Writes the run ID, agent, action and gate decisions to the audit sink (no payload) | Core |
| SH-20 | [guardrail-escalation-handler](guardrail-escalation-handler/SKILL.md) | Handles an escalate or block verdict from the guardrails and routes it to a human | Core |
| SH-21 | [secret-and-pii-handling](secret-and-pii-handling/SKILL.md) | Rules for what may enter a prompt, a ticket or a log; redaction before output | Core |
| SH-22 | [context-budget-management](context-budget-management/SKILL.md) | Summarises and trims context so long runs stay inside the model window | Core |
| SH-23 | [skill-feedback-capture](skill-feedback-capture/SKILL.md) | Records usefulness, corrections and time saved for the vote and iteration cycle | Core |
| SH-24 | [local-model-prompt-style](local-model-prompt-style/SKILL.md) | Prompt conventions that suit the local Qwen model (short steps, explicit output format) | Core |
| SH-25 | [guideline-curation](guideline-curation/SKILL.md) | Manages and updates the agent and factory standard documents and guidelines | Core |
| SH-26 | [notification-dispatch](notification-dispatch/SKILL.md) | Sends status updates to Slack, Teams or email (team's list names Slack) | Adapter |
| SH-27 | [security-policy-enforcement](security-policy-enforcement/SKILL.md) | Verifies at run time that actions follow security rules, using the guardrail verdicts | Core |
| SH-28 | [cost-metering-audit](cost-metering-audit/SKILL.md) | Tracks and reports model token and infrastructure cost per run, agent and application | Core |
| SH-29 | [skill-switch-selection](skill-switch-selection/SKILL.md) | Chooses and loads the right skills and adapter for the phase and tech stack at run time | Core |
| SH-30 | [mcp-tool-access-request](mcp-tool-access-request/SKILL.md) | Requests a tool or MCP scope through the gateway and handles a denial by asking a human or choosing another route | Core |
| SH-31 | [llm-gateway-call-handling](llm-gateway-call-handling/SKILL.md) | Handles gateway outcomes: blocked, redacted, throttled or model unavailable, and retries within limits | Core |
| SH-32 | [observability-signal-emit](observability-signal-emit/SKILL.md) | Emits run traces, step timings and outcome metrics to the observability service (audit events stay in SH-19) | Core |
| SH-33 | [backward-flow-rework-request](backward-flow-rework-request/SKILL.md) | Sends found defects, rollbacks or requested changes back to the owning factory as a bounded rework item, with a rework counter | Core |
