---
name: build-and-test-run
description: "Runs build and unit tests through the stack adapter and returns a normalised result."
---

# build-and-test-run (SH-17)

- Group: Shared skills (used by every factory)
- Skill number: SH-17
- Type: Adapter
- Status: draft v0.1, to be refined in the build and feedback iterations

## 1. Description

Runs build and unit tests through the stack adapter and returns a normalised result.

Human gate: Only where the skill itself is a gate (SH-11). Other shared skills run inside the calling skill's gate.

## 2. Inputs and outputs

- Inputs: repository, stack adapter
- Outputs: normalised build and unit test result

## 3. Tools and permissions

Jira and Confluence only through the MCP gateway, limited to the calling factory's allow-listed operations. Read and write inside the run workspace. No shell unless the skill is an Adapter.

All tool calls pass through the guardrails and the MCP gateway. Anything not listed here is denied.

## 4. Tech stack

Skill logic is common. Commands come from the stack adapter (detect, build and test, coverage, mutation, lint, scan arguments). Supported by adapters for Java (Maven, Gradle), Angular and TypeScript, .NET, Go and Python; add others by adding an adapter.

## 5. Dependencies

SH-08 application-profile-load; SH-10 artifact-handoff-read; SH-09 artifact-handoff-write; SH-19 audit-trail-emit. Platform services: Guardrails, LLM Gateway, MCP Gateway, Context Setting, Audit and Observability apply automatically. SH-07 repo-context-discovery and SH-29 skill-switch-selection choose the adapter.

## 6. Templates

Artifact hand-off envelope; gate evidence pack; audit event format.

## 7. Validation

Output matches its schema; guardrail verdict is allow or redact; no secret or personal data in output; audit event written. Tested on a sample repository for each supported stack.

## 8. Reuse and enhancement

Skill logic stays shared. To support a new tech stack, add a stack adapter rather than editing this skill. Report adapter gaps through SH-23.

## How to run

1. Load the application profile (SH-08) and read the input artifacts.
2. Do the work described above, within the permissions listed.
3. Write the output artifact in its schema (SH-09) and request the human gate where one applies (SH-11).
4. Emit the audit event (SH-19). If a guardrail returns escalate or block, stop and follow SH-20.
