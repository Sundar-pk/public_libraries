---
name: audit-trail-emit
description: "Writes the run ID, agent, action and gate decisions to the audit sink (no payload)."
---

# audit-trail-emit (SH-19)

- Group: Shared skills (used by every factory)
- Skill number: SH-19
- Type: Core
- Status: draft v0.1, to be refined in the build and feedback iterations

## 1. Description

Writes the run ID, agent, action and gate decisions to the audit sink (no payload).

Human gate: Only where the skill itself is a gate (SH-11). Other shared skills run inside the calling skill's gate.

## 2. Inputs and outputs

- Inputs: run ID, agent, action, gate decision
- Outputs: one audit event without payload text

## 3. Tools and permissions

Jira and Confluence only through the MCP gateway, limited to the calling factory's allow-listed operations. Read and write inside the run workspace. No shell unless the skill is an Adapter.

All tool calls pass through the guardrails and the MCP gateway. Anything not listed here is denied.

## 4. Tech stack

Language and stack neutral. Works on documents, tickets, artifacts and tool results. No stack adapter needed.

## 5. Dependencies

SH-08 application-profile-load; SH-10 artifact-handoff-read; SH-09 artifact-handoff-write; SH-19 audit-trail-emit. Platform services: Guardrails, LLM Gateway, MCP Gateway, Context Setting, Audit and Observability apply automatically.

## 6. Templates

Artifact hand-off envelope; gate evidence pack; audit event format.

## 7. Validation

Output matches its schema; guardrail verdict is allow or redact; no secret or personal data in output; audit event written.

## 8. Reuse and enhancement

Shared by all applications. Parameterise through the application profile; do not copy. Improve once here and every factory benefits.

## How to run

1. Load the application profile (SH-08) and read the input artifacts.
2. Do the work described above, within the permissions listed.
3. Write the output artifact in its schema (SH-09) and request the human gate where one applies (SH-11).
4. Emit the audit event (SH-19). If a guardrail returns escalate or block, stop and follow SH-20.
