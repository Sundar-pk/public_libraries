---
name: rollback-readiness-check
description: "Verifies before deployment that the rollback can really be run and data can be restored."
---

# rollback-readiness-check (RL-43)

- Group: xprs-rel: security scanning, release preparation and deployment
- Skill number: RL-43
- Type: Core
- Status: draft v0.1, to be refined in the build and feedback iterations

## 1. Description

Verifies before deployment that the rollback can really be run and data can be restored.

Human gate: Release manager approves the readiness pack. Production deployment always needs a human gate. Risk acceptance needs the security owner.

## 2. Inputs and outputs

- Inputs: rollback plan, environment
- Outputs: readiness check result

## 3. Tools and permissions

Read on code and build outputs. Scanner, pipeline and artifact repository access through the MCP gateway. Deployment only through the approved pipeline, never by direct command. Production changes only after the gate.

All tool calls pass through the guardrails and the MCP gateway. Anything not listed here is denied.

## 4. Tech stack

Language and stack neutral. Works on documents, tickets, artifacts and tool results. No stack adapter needed.

## 5. Dependencies

SH-08 application-profile-load; SH-10 artifact-handoff-read; SH-09 artifact-handoff-write; SH-19 audit-trail-emit. Platform services: Guardrails, LLM Gateway, MCP Gateway, Context Setting, Audit and Observability apply automatically.

## 6. Templates

Release notes, change record, deployment plan, rollback plan, readiness checklist, evidence pack.

## 7. Validation

Scan results normalised; no critical finding open without approved exception; rollback tested before release; post-deploy health compared with baseline.

## 8. Reuse and enhancement

Shared by all applications. Parameterise through the application profile; do not copy. Improve once here and every factory benefits.

## How to run

1. Load the application profile (SH-08) and read the input artifacts.
2. Do the work described above, within the permissions listed.
3. Write the output artifact in its schema (SH-09) and request the human gate where one applies (SH-11).
4. Emit the audit event (SH-19). If a guardrail returns escalate or block, stop and follow SH-20.
