# xprs-rel: security scanning, release preparation and deployment

43 skills.

| No | Skill | Description | Type |
| --- | --- | --- | --- |
| RL-01 | [sast-scan-run](sast-scan-run/SKILL.md) | Runs static application security testing (Fortify or equivalent) | Adapter |
| RL-02 | [sca-dependency-scan](sca-dependency-scan/SKILL.md) | Scans third-party libraries for known vulnerabilities | Adapter |
| RL-03 | [licence-compliance-scan](licence-compliance-scan/SKILL.md) | Checks open-source licences against policy | Adapter |
| RL-04 | [secret-scan-repository](secret-scan-repository/SKILL.md) | Scans code and history for committed secrets | Core |
| RL-05 | [container-image-scan](container-image-scan/SKILL.md) | Scans images for vulnerabilities and base-image drift | Adapter |
| RL-06 | [iac-security-scan](iac-security-scan/SKILL.md) | Scans Terraform, Helm and pipeline files for misconfiguration | Adapter |
| RL-07 | [dast-scan-run](dast-scan-run/SKILL.md) | Runs dynamic scanning against a test environment | Adapter |
| RL-08 | [sonar-quality-gate-read](sonar-quality-gate-read/SKILL.md) | Reads the Sonar quality gate and issue list | Adapter |
| RL-09 | [scan-finding-normalisation](scan-finding-normalisation/SKILL.md) | Converts findings from every tool to one severity scale | Core |
| RL-10 | [scan-finding-triage](scan-finding-triage/SKILL.md) | Groups findings, removes duplicates, proposes false positives for human approval | Core |
| RL-11 | [vulnerability-remediation-plan](vulnerability-remediation-plan/SKILL.md) | Plans fix order by severity, exposure and effort | Core |
| RL-12 | [security-exception-request](security-exception-request/SKILL.md) | Prepares a risk acceptance request with justification and expiry | Core |
| RL-13 | [sbom-generation](sbom-generation/SKILL.md) | Produces the software bill of materials | Adapter |
| RL-14 | [build-artifact-signing-and-provenance](build-artifact-signing-and-provenance/SKILL.md) | Signs artifacts and records build provenance | Adapter |
| RL-15 | [pipeline-definition-generation](pipeline-definition-generation/SKILL.md) | Creates or updates the CI/CD pipeline definition for the stack | Adapter |
| RL-16 | [build-reproducibility-check](build-reproducibility-check/SKILL.md) | Checks the same commit gives the same artifact | Adapter |
| RL-17 | [versioning-and-tagging](versioning-and-tagging/SKILL.md) | Applies semantic version and release tags | Core |
| RL-18 | [artifact-publication](artifact-publication/SKILL.md) | Publishes build outputs to Artifactory with metadata | Adapter |
| RL-19 | [release-scope-assembly](release-scope-assembly/SKILL.md) | Lists the tickets and changes in the release | Core |
| RL-20 | [release-note-compose](release-note-compose/SKILL.md) | Writes release notes for users and operators | Core |
| RL-21 | [release-readiness-checklist](release-readiness-checklist/SKILL.md) | Checks tests, scans, approvals, documentation and runbooks are complete | Core |
| RL-22 | [change-request-preparation](change-request-preparation/SKILL.md) | Prepares the change record with risk, window and rollback | Core |
| RL-23 | [change-risk-assessment](change-risk-assessment/SKILL.md) | Scores release risk from size, history and dependencies | Core |
| RL-24 | [deployment-plan-compose](deployment-plan-compose/SKILL.md) | Writes ordered deployment and verification steps | Core |
| RL-25 | [rollback-plan-compose](rollback-plan-compose/SKILL.md) | Writes and tests the rollback and data-restore steps | Core |
| RL-26 | [configuration-and-secret-promotion](configuration-and-secret-promotion/SKILL.md) | Promotes environment config and secret references safely | Adapter |
| RL-27 | [database-release-coordination](database-release-coordination/SKILL.md) | Sequences schema changes with application deployment | Adapter |
| RL-28 | [environment-provisioning](environment-provisioning/SKILL.md) | Prepares environments from infrastructure as code | Adapter |
| RL-29 | [environment-drift-check](environment-drift-check/SKILL.md) | Compares target environment with the expected state | Adapter |
| RL-30 | [deployment-execution](deployment-execution/SKILL.md) | Runs the deployment through the approved pipeline | Adapter |
| RL-31 | [canary-and-blue-green-rollout](canary-and-blue-green-rollout/SKILL.md) | Controls progressive rollout and traffic shift | Adapter |
| RL-32 | [feature-flag-rollout](feature-flag-rollout/SKILL.md) | Turns features on by cohort with monitoring | Adapter |
| RL-33 | [smoke-test-after-deploy](smoke-test-after-deploy/SKILL.md) | Runs post-deployment smoke checks | Adapter |
| RL-34 | [post-deploy-health-verification](post-deploy-health-verification/SKILL.md) | Compares error rate, latency and saturation with the baseline | Core |
| RL-35 | [automatic-rollback-decision](automatic-rollback-decision/SKILL.md) | Recommends rollback when health thresholds are breached | Core |
| RL-36 | [release-approval-gate-pack](release-approval-gate-pack/SKILL.md) | Prepares the evidence pack for the production gate | Core |
| RL-37 | [deployment-record-update](deployment-record-update/SKILL.md) | Updates change record, ticket and release status | Core |
| RL-38 | [hypercare-monitoring-plan](hypercare-monitoring-plan/SKILL.md) | Defines extra monitoring and owners for the first days after release | Core |
| RL-39 | [release-calendar-and-freeze-check](release-calendar-and-freeze-check/SKILL.md) | Checks freeze windows and conflicting releases | Core |
| RL-40 | [release-retrospective-data](release-retrospective-data/SKILL.md) | Collects outcome and issues for the release review | Core |
| RL-41 | [ci-pipeline-trigger](ci-pipeline-trigger/SKILL.md) | Starts and monitors runs on the CI/CD server (Jenkins in the team's list) | Adapter |
| RL-42 | [pipeline-validation](pipeline-validation/SKILL.md) | Checks that CI/CD pipelines are configured correctly: stages, gates, secrets and permissions | Adapter |
| RL-43 | [rollback-readiness-check](rollback-readiness-check/SKILL.md) | Verifies before deployment that the rollback can really be run and data can be restored | Core |
