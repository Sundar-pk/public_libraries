---
name: build-reproducibility-check
description: "Checks the same commit gives the same artifact."
---

# build-reproducibility-check (RL-16)

- Group: xprs-rel: security scanning, release preparation and deployment
- Skill number: RL-16
- Type: Adapter
- Status: draft v0.1, to be refined in the build and feedback iterations

## 1. Description

Checks the same commit gives the same artifact.

Human gate: Release manager approves the readiness pack. Production deployment always needs a human gate. Risk acceptance needs the security owner.

## 2. Inputs and outputs

- Inputs: commit, build
- Outputs: reproducibility check result

## 3. Tools and permissions

Read on code and build outputs. Scanner, pipeline and artifact repository access through the MCP gateway. Deployment only through the approved pipeline, never by direct command. Production changes only after the gate.

All tool calls pass through the guardrails and the MCP gateway. Anything not listed here is denied.

## 4. Tech stack

Skill logic is common. Commands come from the stack adapter (detect, build and test, coverage, mutation, lint, scan arguments). Supported by adapters for Java (Maven, Gradle), Angular and TypeScript, .NET, Go and Python; add others by adding an adapter.

## 5. Dependencies

SH-08 application-profile-load; SH-10 artifact-handoff-read; SH-09 artifact-handoff-write; SH-19 audit-trail-emit. Platform services: Guardrails, LLM Gateway, MCP Gateway, Context Setting, Audit and Observability apply automatically. SH-07 repo-context-discovery and SH-29 skill-switch-selection choose the adapter.

## 6. Templates

Release notes, change record, deployment plan, rollback plan, readiness checklist, evidence pack.

## 7. Validation

Scan results normalised; no critical finding open without approved exception; rollback tested before release; post-deploy health compared with baseline. Tested on a sample repository for each supported stack.

## 8. Reuse and enhancement

Skill logic stays shared. To support a new tech stack, add a stack adapter rather than editing this skill. Report adapter gaps through SH-23.

## How to run

1. Load the application profile (SH-08) and read the input artifacts.
2. Do the work described above, within the permissions listed.
3. Write the output artifact in its schema (SH-09) and request the human gate where one applies (SH-11).
4. Emit the audit event (SH-19). If a guardrail returns escalate or block, stop and follow SH-20.
