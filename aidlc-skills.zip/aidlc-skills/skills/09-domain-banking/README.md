# Domain-specific skills (banking)

3 skills.

| No | Skill | Description | Type |
| --- | --- | --- | --- |
| DM-01 | [banking-api-design-rules](banking-api-design-rules/SKILL.md) | Applies the bank's API standards to designs and contracts | Domain |
| DM-02 | [transaction-integrity-check](transaction-integrity-check/SKILL.md) | Checks financial logic keeps ACID properties, idempotency and reconciliation | Domain |
| DM-03 | [compliance-rule-validation](compliance-rule-validation/SKILL.md) | Checks logic and requirements against regulatory requirements | Domain |
