---
name: compliance-rule-validation
description: "Checks logic and requirements against regulatory requirements."
---

# compliance-rule-validation (DM-03)

- Group: Domain-specific skills (banking)
- Skill number: DM-03
- Type: Domain
- Status: draft v0.1, to be refined in the build and feedback iterations

## 1. Description

Checks logic and requirements against regulatory requirements.

Human gate: Domain or compliance owner confirms findings before they block a release.

## 2. Inputs and outputs

- Inputs: requirements or logic, regulations
- Outputs: compliance findings with the rule referenced

## 3. Tools and permissions

Read on design, code and requirements. Write findings inside the workspace. No shell.

All tool calls pass through the guardrails and the MCP gateway. Anything not listed here is denied.

## 4. Tech stack

Language neutral. Rules come from the banking domain pack named in the application profile.

## 5. Dependencies

SH-08 application-profile-load; SH-10 artifact-handoff-read; SH-09 artifact-handoff-write; SH-19 audit-trail-emit. Platform services: Guardrails, LLM Gateway, MCP Gateway, Context Setting, Audit and Observability apply automatically.

## 6. Templates

Banking API standard checklist, transaction integrity checklist, compliance finding record.

## 7. Validation

Each finding cites the rule or standard; rules versioned in the application profile; false positives reviewed by the domain owner.

## 8. Reuse and enhancement

Reuse across every banking application. Update the rule set in the domain pack, not in the skill text.

## How to run

1. Load the application profile (SH-08) and read the input artifacts.
2. Do the work described above, within the permissions listed.
3. Write the output artifact in its schema (SH-09) and request the human gate where one applies (SH-11).
4. Emit the audit event (SH-19). If a guardrail returns escalate or block, stop and follow SH-20.
