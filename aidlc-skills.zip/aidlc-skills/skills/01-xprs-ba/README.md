# xprs-ba / bdd-forge-ba: business analysis

39 skills.

| No | Skill | Description | Type |
| --- | --- | --- | --- |
| BA-01 | [idea-intake-capture](idea-intake-capture/SKILL.md) | Captures a raw idea with sponsor, problem and expected outcome | Core |
| BA-02 | [problem-statement-writer](problem-statement-writer/SKILL.md) | Writes a one-paragraph problem statement and success measure | Core |
| BA-03 | [stakeholder-identification](stakeholder-identification/SKILL.md) | Lists stakeholders, roles, interest and influence | Core |
| BA-04 | [business-case-draft](business-case-draft/SKILL.md) | Drafts benefits, cost range, risks and alternatives | Core |
| BA-05 | [feasibility-screening](feasibility-screening/SKILL.md) | Screens an idea for technical, data, legal and capacity feasibility | Core |
| BA-06 | [idea-prioritisation-scoring](idea-prioritisation-scoring/SKILL.md) | Scores ideas on value, effort, risk and strategic fit | Core |
| BA-07 | [existing-solution-check](existing-solution-check/SKILL.md) | Searches the portfolio for an existing application or service that already does this | Core |
| BA-08 | [product-vision-and-scope](product-vision-and-scope/SKILL.md) | Writes vision, in-scope, out-of-scope and boundaries | Core |
| BA-09 | [stakeholder-interview-guide](stakeholder-interview-guide/SKILL.md) | Prepares questions for each stakeholder group | Core |
| BA-10 | [interview-notes-structuring](interview-notes-structuring/SKILL.md) | Turns raw meeting notes into structured findings | Core |
| BA-11 | [workshop-facilitation-pack](workshop-facilitation-pack/SKILL.md) | Builds the agenda, exercises and outputs for a requirements workshop | Core |
| BA-12 | [source-document-ingestion](source-document-ingestion/SKILL.md) | Reads emails, decks and specs and extracts requirement candidates | Core |
| BA-13 | [business-process-as-is-mapping](business-process-as-is-mapping/SKILL.md) | Describes the current process step by step | Core |
| BA-14 | [business-process-to-be-mapping](business-process-to-be-mapping/SKILL.md) | Describes the target process and what changes | Core |
| BA-15 | [user-persona-and-journey](user-persona-and-journey/SKILL.md) | Writes personas and journeys for the affected users | Core |
| BA-16 | [functional-requirement-writer](functional-requirement-writer/SKILL.md) | Writes atomic, testable functional requirements with IDs | Core |
| BA-17 | [non-functional-requirement-writer](non-functional-requirement-writer/SKILL.md) | Writes performance, availability, security, accessibility and audit needs with numbers | Core |
| BA-18 | [business-rule-extraction](business-rule-extraction/SKILL.md) | Extracts rules and decision tables from text | Core |
| BA-19 | [data-requirement-capture](data-requirement-capture/SKILL.md) | Lists entities, fields, sources, retention and data classification | Core |
| BA-20 | [integration-requirement-capture](integration-requirement-capture/SKILL.md) | Lists systems, interfaces, direction, volume and owners | Core |
| BA-21 | [regulatory-and-compliance-mapping](regulatory-and-compliance-mapping/SKILL.md) | Maps requirements to policies and regulations that apply | Core |
| BA-22 | [user-story-writer](user-story-writer/SKILL.md) | Converts requirements to stories in the agreed format | Core |
| BA-23 | [acceptance-criteria-writer](acceptance-criteria-writer/SKILL.md) | Writes Given/When/Then criteria for each story | Core |
| BA-24 | [edge-case-and-negative-scenario](edge-case-and-negative-scenario/SKILL.md) | Adds error, boundary and abuse scenarios to each story | Core |
| BA-25 | [requirement-ambiguity-check](requirement-ambiguity-check/SKILL.md) | Flags vague words, conflicts and missing values | Core |
| BA-26 | [requirement-completeness-check](requirement-completeness-check/SKILL.md) | Checks coverage against the requirement template | Core |
| BA-27 | [requirement-conflict-detection](requirement-conflict-detection/SKILL.md) | Finds contradictions between requirements and across applications | Core |
| BA-28 | [requirement-glossary-builder](requirement-glossary-builder/SKILL.md) | Builds the domain glossary and keeps terms consistent | Core |
| BA-29 | [requirement-document-compose](requirement-document-compose/SKILL.md) | Assembles the full requirement document from approved parts | Core |
| BA-30 | [requirement-review-pack](requirement-review-pack/SKILL.md) | Prepares the review pack for the product owner gate | Core |
| BA-31 | [requirement-change-impact](requirement-change-impact/SKILL.md) | Assesses the impact of a changed requirement on scope and tests | Core |
| BA-32 | [epic-creation](epic-creation/SKILL.md) | Creates the Jira epic with goal, scope and links | Core |
| BA-33 | [story-breakdown-and-slicing](story-breakdown-and-slicing/SKILL.md) | Slices epics into small, independently deliverable stories | Core |
| BA-34 | [story-estimation-support](story-estimation-support/SKILL.md) | Proposes size from similar past stories; the team confirms | Core |
| BA-35 | [definition-of-ready-check](definition-of-ready-check/SKILL.md) | Verifies a story meets the team's definition of ready | Core |
| BA-36 | [dependency-and-risk-mapping](dependency-and-risk-mapping/SKILL.md) | Records dependencies between stories, teams and systems | Core |
| BA-37 | [backlog-hygiene](backlog-hygiene/SKILL.md) | Finds duplicates, stale items and missing fields in the backlog | Core |
| BA-38 | [stakeholder-signoff-record](stakeholder-signoff-record/SKILL.md) | Records who approved what and when, linked to the version | Core |
| BA-39 | [wireframe-translation](wireframe-translation/SKILL.md) | Converts wireframes and visual designs into requirements and acceptance criteria | Core |
