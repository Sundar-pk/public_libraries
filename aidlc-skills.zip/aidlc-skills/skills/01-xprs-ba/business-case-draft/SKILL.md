---
name: business-case-draft
description: "Drafts benefits, cost range, risks and alternatives."
---

# business-case-draft (BA-04)

- Group: xprs-ba / bdd-forge-ba: business analysis
- Skill number: BA-04
- Type: Core
- Phase: Ideation
- Status: draft v0.1, to be refined in the build and feedback iterations

## 1. Description

Drafts benefits, cost range, risks and alternatives.

Human gate: Product owner approves requirements, epic and stories before xprs-sp or xprs-arch consume them.

## 2. Inputs and outputs

- Inputs: idea record, stakeholders
- Outputs: business case draft: benefits, cost range, risks, alternatives

## 3. Tools and permissions

Read-only on the repository. Jira create and update (epic, story) and Confluence read and publish through the MCP gateway. No shell, no code write.

All tool calls pass through the guardrails and the MCP gateway. Anything not listed here is denied.

## 4. Tech stack

Language and stack neutral. Works on documents, tickets, artifacts and tool results. No stack adapter needed.

## 5. Dependencies

SH-08 application-profile-load; SH-10 artifact-handoff-read; SH-09 artifact-handoff-write; SH-19 audit-trail-emit. Platform services: Guardrails, LLM Gateway, MCP Gateway, Context Setting, Audit and Observability apply automatically.

## 6. Templates

Requirement document, user story, acceptance criteria (Given/When/Then), epic, glossary, review pack.

## 7. Validation

Every requirement has an ID, is atomic and testable; no vague terms left unflagged; links to source retained; product owner gate recorded.

## 8. Reuse and enhancement

Shared by all applications. Parameterise through the application profile; do not copy. Improve once here and every factory benefits.

## How to run

1. Load the application profile (SH-08) and read the input artifacts.
2. Do the work described above, within the permissions listed.
3. Write the output artifact in its schema (SH-09) and request the human gate where one applies (SH-11).
4. Emit the audit event (SH-19). If a guardrail returns escalate or block, stop and follow SH-20.
