---
name: data-model-design
description: "Designs entities, relations, keys and indexes."
---

# data-model-design (AR-13)

- Group: xprs-arch: architecture, security design and test strategy
- Skill number: AR-13
- Type: Adapter
- Status: draft v0.1, to be refined in the build and feedback iterations

## 1. Description

Designs entities, relations, keys and indexes.

Human gate: Architect or board approves design, ADRs and threat model before xprs-dev starts.

## 2. Inputs and outputs

- Inputs: requirements, data needs
- Outputs: data model: entities, relations, keys, indexes

## 3. Tools and permissions

Read on repository and requirements. Write design documents and diagrams inside the workspace. Confluence publish through the MCP gateway. No shell except diagram rendering.

All tool calls pass through the guardrails and the MCP gateway. Anything not listed here is denied.

## 4. Tech stack

Skill logic is common. Commands come from the stack adapter (detect, build and test, coverage, mutation, lint, scan arguments). Supported by adapters for Java (Maven, Gradle), Angular and TypeScript, .NET, Go and Python; add others by adding an adapter.

## 5. Dependencies

SH-08 application-profile-load; SH-10 artifact-handoff-read; SH-09 artifact-handoff-write; SH-19 audit-trail-emit. Platform services: Guardrails, LLM Gateway, MCP Gateway, Context Setting, Audit and Observability apply automatically. SH-07 repo-context-discovery and SH-29 skill-switch-selection choose the adapter.

## 6. Templates

Technical design document, ADR, C4 diagrams, threat model, API contract (OpenAPI or AsyncAPI), test strategy.

## 7. Validation

Design traces to requirements; standards check passed; each decision has alternatives and reasons; security requirements derived from threats; architecture gate recorded. Tested on a sample repository for each supported stack.

## 8. Reuse and enhancement

Skill logic stays shared. To support a new tech stack, add a stack adapter rather than editing this skill. Report adapter gaps through SH-23.

## How to run

1. Load the application profile (SH-08) and read the input artifacts.
2. Do the work described above, within the permissions listed.
3. Write the output artifact in its schema (SH-09) and request the human gate where one applies (SH-11).
4. Emit the audit event (SH-19). If a guardrail returns escalate or block, stop and follow SH-20.
