---
name: event-and-messaging-design
description: "Designs topics, schemas, ordering, retry and dead letters."
---

# event-and-messaging-design (AR-12)

- Group: xprs-arch: architecture, security design and test strategy
- Skill number: AR-12
- Type: Core
- Status: draft v0.1, to be refined in the build and feedback iterations

## 1. Description

Designs topics, schemas, ordering, retry and dead letters.

Human gate: Architect or board approves design, ADRs and threat model before xprs-dev starts.

## 2. Inputs and outputs

- Inputs: requirements, design
- Outputs: topics, schemas, ordering and retry design

## 3. Tools and permissions

Read on repository and requirements. Write design documents and diagrams inside the workspace. Confluence publish through the MCP gateway. No shell except diagram rendering.

All tool calls pass through the guardrails and the MCP gateway. Anything not listed here is denied.

## 4. Tech stack

Language and stack neutral. Works on documents, tickets, artifacts and tool results. No stack adapter needed.

## 5. Dependencies

SH-08 application-profile-load; SH-10 artifact-handoff-read; SH-09 artifact-handoff-write; SH-19 audit-trail-emit. Platform services: Guardrails, LLM Gateway, MCP Gateway, Context Setting, Audit and Observability apply automatically.

## 6. Templates

Technical design document, ADR, C4 diagrams, threat model, API contract (OpenAPI or AsyncAPI), test strategy.

## 7. Validation

Design traces to requirements; standards check passed; each decision has alternatives and reasons; security requirements derived from threats; architecture gate recorded.

## 8. Reuse and enhancement

Shared by all applications. Parameterise through the application profile; do not copy. Improve once here and every factory benefits.

## How to run

1. Load the application profile (SH-08) and read the input artifacts.
2. Do the work described above, within the permissions listed.
3. Write the output artifact in its schema (SH-09) and request the human gate where one applies (SH-11).
4. Emit the audit event (SH-19). If a guardrail returns escalate or block, stop and follow SH-20.
