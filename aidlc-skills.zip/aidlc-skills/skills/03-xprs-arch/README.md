# xprs-arch: architecture, security design and test strategy

35 skills.

| No | Skill | Description | Type |
| --- | --- | --- | --- |
| AR-01 | [requirement-to-architecture-analysis](requirement-to-architecture-analysis/SKILL.md) | Extracts architecturally significant requirements and quality attributes | Core |
| AR-02 | [architecture-option-generation](architecture-option-generation/SKILL.md) | Produces two or three candidate designs with trade-offs | Core |
| AR-03 | [architecture-decision-record](architecture-decision-record/SKILL.md) | Writes an ADR: context, decision, alternatives, consequences | Core |
| AR-04 | [enterprise-standards-check](enterprise-standards-check/SKILL.md) | Checks the design against approved patterns, technologies and principles | Core |
| AR-05 | [reference-architecture-selection](reference-architecture-selection/SKILL.md) | Picks the matching reference architecture or blueprint | Core |
| AR-06 | [c4-context-diagram](c4-context-diagram/SKILL.md) | Draws the system context diagram | Core |
| AR-07 | [c4-container-component-diagram](c4-container-component-diagram/SKILL.md) | Draws containers and components with responsibilities | Core |
| AR-08 | [sequence-and-flow-diagram](sequence-and-flow-diagram/SKILL.md) | Draws key interaction flows and failure paths | Core |
| AR-09 | [deployment-topology-design](deployment-topology-design/SKILL.md) | Designs environments, network zones, scaling and failover | Core |
| AR-10 | [api-contract-design](api-contract-design/SKILL.md) | Designs REST or event contracts in OpenAPI or AsyncAPI | Adapter |
| AR-11 | [api-versioning-and-compatibility](api-versioning-and-compatibility/SKILL.md) | Defines versioning and backward-compatibility rules | Core |
| AR-12 | [event-and-messaging-design](event-and-messaging-design/SKILL.md) | Designs topics, schemas, ordering, retry and dead letters | Core |
| AR-13 | [data-model-design](data-model-design/SKILL.md) | Designs entities, relations, keys and indexes | Adapter |
| AR-14 | [data-migration-design](data-migration-design/SKILL.md) | Designs migration steps, rollback and reconciliation | Core |
| AR-15 | [data-classification-and-retention](data-classification-and-retention/SKILL.md) | Assigns classification, retention and masking per field | Core |
| AR-16 | [integration-pattern-selection](integration-pattern-selection/SKILL.md) | Chooses sync, async, batch or streaming for each interface | Core |
| AR-17 | [threat-modelling](threat-modelling/SKILL.md) | Builds a threat model (STRIDE) with data flows and trust boundaries | Core |
| AR-18 | [security-requirement-derivation](security-requirement-derivation/SKILL.md) | Turns threats into concrete security requirements | Core |
| AR-19 | [authn-authz-design](authn-authz-design/SKILL.md) | Designs identity, roles, scopes and token handling | Core |
| AR-20 | [secrets-and-key-management-design](secrets-and-key-management-design/SKILL.md) | Designs how secrets are stored, rotated and injected | Core |
| AR-21 | [privacy-impact-assessment](privacy-impact-assessment/SKILL.md) | Assesses personal data use and legal basis | Core |
| AR-22 | [resilience-design](resilience-design/SKILL.md) | Designs timeouts, retries, circuit breakers and graceful degradation | Core |
| AR-23 | [performance-and-capacity-design](performance-and-capacity-design/SKILL.md) | Estimates load, sizing and performance budgets | Core |
| AR-24 | [observability-design](observability-design/SKILL.md) | Defines logs, metrics, traces, alerts and dashboards for the design | Core |
| AR-25 | [cost-estimation](cost-estimation/SKILL.md) | Estimates run and build cost of each option | Core |
| AR-26 | [build-versus-buy-assessment](build-versus-buy-assessment/SKILL.md) | Compares build, buy and reuse | Core |
| AR-27 | [technology-selection-record](technology-selection-record/SKILL.md) | Records technology choices against the approved catalogue | Core |
| AR-28 | [design-document-compose](design-document-compose/SKILL.md) | Assembles the technical design document from approved parts | Core |
| AR-29 | [design-review-pack](design-review-pack/SKILL.md) | Prepares the architecture board pack with open risks | Core |
| AR-30 | [design-to-task-mapping](design-to-task-mapping/SKILL.md) | Maps design components to implementation tasks for xprs-dev | Core |
| AR-31 | [test-strategy-design](test-strategy-design/SKILL.md) | Defines test levels, coverage targets, data and environments | Core |
| AR-32 | [non-functional-test-plan](non-functional-test-plan/SKILL.md) | Plans performance, security, resilience and accessibility tests | Core |
| AR-33 | [testability-review](testability-review/SKILL.md) | Checks that the design can be tested and mocked | Core |
| AR-34 | [architecture-conformance-check](architecture-conformance-check/SKILL.md) | Compares built code and structure to the approved design | Adapter |
| AR-35 | [service-dependency-call-chain-mapping](service-dependency-call-chain-mapping/SKILL.md) | Maps service-to-service call chains and what breaks if one fails | Core |
