# xprs-sp: sprint planning and delivery management

23 skills.

| No | Skill | Description | Type |
| --- | --- | --- | --- |
| SP-01 | [sprint-goal-drafting](sprint-goal-drafting/SKILL.md) | Proposes a sprint goal from the top of the backlog | Core |
| SP-02 | [capacity-calculation](capacity-calculation/SKILL.md) | Calculates team capacity from calendar, leave and ceremonies | Core |
| SP-03 | [velocity-trend-analysis](velocity-trend-analysis/SKILL.md) | Reads past sprints to give a realistic commitment range | Core |
| SP-04 | [sprint-backlog-selection](sprint-backlog-selection/SKILL.md) | Proposes the story set that fits goal and capacity | Core |
| SP-05 | [dependency-sequencing](dependency-sequencing/SKILL.md) | Orders stories by technical and team dependencies | Core |
| SP-06 | [cross-team-dependency-tracking](cross-team-dependency-tracking/SKILL.md) | Tracks work that waits on another team or vendor | Core |
| SP-07 | [task-breakdown-assignment](task-breakdown-assignment/SKILL.md) | Splits stories into tasks and suggests owners by skill | Core |
| SP-08 | [release-train-alignment](release-train-alignment/SKILL.md) | Aligns sprint content to the release calendar and freeze dates | Core |
| SP-09 | [risk-and-blocker-register](risk-and-blocker-register/SKILL.md) | Maintains risks, blockers and mitigation owners | Core |
| SP-10 | [daily-progress-digest](daily-progress-digest/SKILL.md) | Summarises ticket movement since yesterday for the stand-up | Core |
| SP-11 | [blocked-item-chaser](blocked-item-chaser/SKILL.md) | Finds stale or blocked tickets and drafts the nudge | Core |
| SP-12 | [scope-change-assessment](scope-change-assessment/SKILL.md) | Assesses mid-sprint additions and the trade-off | Core |
| SP-13 | [burndown-and-forecast](burndown-and-forecast/SKILL.md) | Produces burndown and a completion forecast | Core |
| SP-14 | [work-in-progress-limit-check](work-in-progress-limit-check/SKILL.md) | Flags too many items in progress per person or column | Core |
| SP-15 | [sprint-review-pack](sprint-review-pack/SKILL.md) | Builds the demo list and the done-versus-planned summary | Core |
| SP-16 | [retrospective-data-pack](retrospective-data-pack/SKILL.md) | Gathers facts for the retrospective: carry-over, defects, cycle time | Core |
| SP-17 | [retrospective-action-tracking](retrospective-action-tracking/SKILL.md) | Tracks retrospective actions to closure | Core |
| SP-18 | [delivery-metrics-dashboard](delivery-metrics-dashboard/SKILL.md) | Reports lead time, cycle time, throughput and escaped defects | Core |
| SP-19 | [dora-metrics-collection](dora-metrics-collection/SKILL.md) | Collects deployment frequency, lead time, change failure rate and restore time | Core |
| SP-20 | [stakeholder-status-report](stakeholder-status-report/SKILL.md) | Writes the weekly status for sponsors in plain language | Core |
| SP-21 | [release-note-draft](release-note-draft/SKILL.md) | Drafts release notes from completed tickets | Core |
| SP-22 | [ai-productivity-measurement](ai-productivity-measurement/SKILL.md) | Measures time saved by agents against a baseline for the CIO's value case | Core |
| SP-23 | [sprint-risk-assessment](sprint-risk-assessment/SKILL.md) | Identifies technical and delivery risks for each sprint before it starts | Core |
