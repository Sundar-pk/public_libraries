---
name: release-note-draft
description: "Drafts release notes from completed tickets."
---

# release-note-draft (SP-21)

- Group: xprs-sp: sprint planning and delivery management
- Skill number: SP-21
- Type: Core
- Phase: Release
- Status: draft v0.1, to be refined in the build and feedback iterations

## 1. Description

Drafts release notes from completed tickets.

Human gate: Team confirms the sprint commitment and any scope change. Reports are informational.

## 2. Inputs and outputs

- Inputs: completed tickets
- Outputs: draft release notes

## 3. Tools and permissions

Read on Jira boards and sprint data through the MCP gateway; write comments and sprint fields only. Read on the pipeline and incident data. No shell, no code write.

All tool calls pass through the guardrails and the MCP gateway. Anything not listed here is denied.

## 4. Tech stack

Language and stack neutral. Works on documents, tickets, artifacts and tool results. No stack adapter needed.

## 5. Dependencies

SH-08 application-profile-load; SH-10 artifact-handoff-read; SH-09 artifact-handoff-write; SH-19 audit-trail-emit. Platform services: Guardrails, LLM Gateway, MCP Gateway, Context Setting, Audit and Observability apply automatically.

## 6. Templates

Sprint plan, capacity sheet, daily digest, status report, retrospective pack.

## 7. Validation

Numbers recomputed from source data; every proposal shows its basis; team confirmation recorded for commitments.

## 8. Reuse and enhancement

Shared by all applications. Parameterise through the application profile; do not copy. Improve once here and every factory benefits.

## How to run

1. Load the application profile (SH-08) and read the input artifacts.
2. Do the work described above, within the permissions listed.
3. Write the output artifact in its schema (SH-09) and request the human gate where one applies (SH-11).
4. Emit the audit event (SH-19). If a guardrail returns escalate or block, stop and follow SH-20.
