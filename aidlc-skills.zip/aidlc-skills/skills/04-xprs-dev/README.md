# xprs-dev: analysis, TDD, implementation, review and merge request

59 skills.

| No | Skill | Description | Type |
| --- | --- | --- | --- |
| DV-01 | [xprs-dev-analysis](xprs-dev-analysis/SKILL.md) | Analyses the ticket and codebase impact (exists today) | Core |
| DV-02 | [codebase-impact-analysis](codebase-impact-analysis/SKILL.md) | Finds the modules, classes and tests a change touches | Adapter |
| DV-03 | [dependency-graph-analysis](dependency-graph-analysis/SKILL.md) | Maps internal and third-party dependencies of the change area | Adapter |
| DV-04 | [existing-pattern-discovery](existing-pattern-discovery/SKILL.md) | Finds how similar features are already built here, to copy the style | Adapter |
| DV-05 | [reusable-component-search](reusable-component-search/SKILL.md) | Searches internal libraries and services before writing new code | Core |
| DV-06 | [api-and-contract-impact](api-and-contract-impact/SKILL.md) | Checks the change against consumers and published contracts | Core |
| DV-07 | [xprs-dev-technical-task-planning](xprs-dev-technical-task-planning/SKILL.md) | Plans ordered technical tasks (exists today) | Core |
| DV-08 | [task-estimation-and-risk](task-estimation-and-risk/SKILL.md) | Estimates effort and flags risky tasks | Core |
| DV-09 | [feature-branch-setup](feature-branch-setup/SKILL.md) | Creates the branch with the naming convention | Core |
| DV-10 | [local-environment-bootstrap](local-environment-bootstrap/SKILL.md) | Prepares dependencies, config and local services to run tests | Adapter |
| DV-11 | [baseline-build-and-test](baseline-build-and-test/SKILL.md) | Runs build and tests before any change, to know the starting state | Adapter |
| DV-12 | [test-case-derivation](test-case-derivation/SKILL.md) | Derives test cases from acceptance criteria and edge cases | Core |
| DV-13 | [failing-test-writer](failing-test-writer/SKILL.md) | Writes the failing unit test first (red) | Adapter |
| DV-14 | [test-data-and-fixture-builder](test-data-and-fixture-builder/SKILL.md) | Builds fixtures, builders and anonymised data | Adapter |
| DV-15 | [mock-and-stub-generation](mock-and-stub-generation/SKILL.md) | Generates mocks for external systems and dependencies | Adapter |
| DV-16 | [red-state-verification](red-state-verification/SKILL.md) | Proves the new test fails for the right reason | Adapter |
| DV-17 | [minimal-implementation](minimal-implementation/SKILL.md) | Writes the smallest code that makes the test pass (green) | Adapter |
| DV-18 | [refactor-with-green-tests](refactor-with-green-tests/SKILL.md) | Cleans up while keeping tests green | Adapter |
| DV-19 | [tdd-cycle-orchestration](tdd-cycle-orchestration/SKILL.md) | Controls red, green, refactor per task and blocks skipping | Core |
| DV-20 | [api-endpoint-implementation](api-endpoint-implementation/SKILL.md) | Implements controllers, handlers and routes to the contract | Adapter |
| DV-21 | [service-and-domain-logic-implementation](service-and-domain-logic-implementation/SKILL.md) | Implements business logic with the approved rules | Adapter |
| DV-22 | [persistence-implementation](persistence-implementation/SKILL.md) | Implements repositories, queries and entity mapping | Adapter |
| DV-23 | [database-migration-script](database-migration-script/SKILL.md) | Writes versioned schema migrations with rollback | Adapter |
| DV-24 | [ui-component-implementation](ui-component-implementation/SKILL.md) | Builds UI components, forms and state handling | Adapter |
| DV-25 | [ui-accessibility-implementation](ui-accessibility-implementation/SKILL.md) | Applies accessibility rules to UI code | Adapter |
| DV-26 | [integration-client-implementation](integration-client-implementation/SKILL.md) | Implements clients for other systems with retries and timeouts | Adapter |
| DV-27 | [messaging-producer-consumer-implementation](messaging-producer-consumer-implementation/SKILL.md) | Implements event publishers and consumers | Adapter |
| DV-28 | [configuration-and-feature-flag](configuration-and-feature-flag/SKILL.md) | Adds externalised config and feature flags | Adapter |
| DV-29 | [error-handling-and-validation](error-handling-and-validation/SKILL.md) | Adds input validation and consistent error responses | Adapter |
| DV-30 | [logging-metrics-tracing-instrumentation](logging-metrics-tracing-instrumentation/SKILL.md) | Adds structured logs, metrics and trace context | Adapter |
| DV-31 | [secure-coding-application](secure-coding-application/SKILL.md) | Applies input handling, output encoding, authz checks and safe crypto use | Adapter |
| DV-32 | [dependency-addition-check](dependency-addition-check/SKILL.md) | Checks a new library for licence, version, vulnerability and approval | Adapter |
| DV-33 | [idempotency-and-concurrency-handling](idempotency-and-concurrency-handling/SKILL.md) | Adds idempotency keys, locking and safe retries | Adapter |
| DV-34 | [unit-test-completion](unit-test-completion/SKILL.md) | Fills missing unit tests for changed code | Adapter |
| DV-35 | [integration-test-writer](integration-test-writer/SKILL.md) | Writes tests against real or containerised dependencies | Adapter |
| DV-36 | [contract-test-writer](contract-test-writer/SKILL.md) | Writes consumer or provider contract tests | Adapter |
| DV-37 | [coverage-measurement](coverage-measurement/SKILL.md) | Measures line and branch coverage on changed code | Adapter |
| DV-38 | [coverage-gap-closure](coverage-gap-closure/SKILL.md) | Writes tests for uncovered branches until the target is met | Adapter |
| DV-39 | [mutation-test-run](mutation-test-run/SKILL.md) | Runs mutation testing (optional gate) | Adapter |
| DV-40 | [mutation-survivor-analysis](mutation-survivor-analysis/SKILL.md) | Explains surviving mutants and adds tests to kill them | Adapter |
| DV-41 | [flaky-test-detection](flaky-test-detection/SKILL.md) | Reruns suspect tests and flags unstable ones | Adapter |
| DV-42 | [lint-and-format-run](lint-and-format-run/SKILL.md) | Runs the linter and formatter from the stack adapter | Adapter |
| DV-43 | [lint-fix-loop](lint-fix-loop/SKILL.md) | Fixes lint findings in a bounded loop, then asks for help | Adapter |
| DV-44 | [static-analysis-local](static-analysis-local/SKILL.md) | Runs local static analysis before the pipeline scans | Adapter |
| DV-45 | [code-self-review](code-self-review/SKILL.md) | Reviews its own diff against standards, design and acceptance criteria | Core |
| DV-46 | [design-conformance-check](design-conformance-check/SKILL.md) | Checks the code follows the approved design and ADRs | Core |
| DV-47 | [documentation-and-comment-update](documentation-and-comment-update/SKILL.md) | Updates README, API docs and code comments | Core |
| DV-48 | [changelog-entry](changelog-entry/SKILL.md) | Adds the changelog entry for the change | Core |
| DV-49 | [peer-review-assist](peer-review-assist/SKILL.md) | Reviews another change: bugs, style, security and test quality | Core |
| DV-50 | [review-comment-resolution](review-comment-resolution/SKILL.md) | Addresses reviewer comments and re-runs checks | Core |
| DV-51 | [sonar-finding-fix](sonar-finding-fix/SKILL.md) | Fixes Sonar issues reported on the change | Adapter |
| DV-52 | [fortify-finding-fix](fortify-finding-fix/SKILL.md) | Fixes Fortify findings, with a human gate for false-positive claims | Adapter |
| DV-53 | [commit-message-compose](commit-message-compose/SKILL.md) | Writes a commit message from the diff and ticket | Core |
| DV-54 | [merge-request-description](merge-request-description/SKILL.md) | Writes the MR description: change, tests, risks, evidence | Core |
| DV-55 | [merge-conflict-resolution](merge-conflict-resolution/SKILL.md) | Resolves conflicts and re-runs tests | Adapter |
| DV-56 | [pipeline-failure-triage](pipeline-failure-triage/SKILL.md) | Reads failed CI logs and proposes the fix | Adapter |
| DV-57 | [ticket-completion-update](ticket-completion-update/SKILL.md) | Completion stage: updates the Jira ticket and links the MR (exists as a stage today) | Core |
| DV-58 | [local-run-and-smoke-check](local-run-and-smoke-check/SKILL.md) | Starts the app locally and checks the main path works | Adapter |
| DV-59 | [tdd-completeness-verification](tdd-completeness-verification/SKILL.md) | Validates that the code satisfies every TDD requirement: a test per criterion, red seen first, all green | Core |
