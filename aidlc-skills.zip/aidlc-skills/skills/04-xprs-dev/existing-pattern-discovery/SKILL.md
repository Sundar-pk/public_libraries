---
name: existing-pattern-discovery
description: "Finds how similar features are already built here, to copy the style."
---

# existing-pattern-discovery (DV-04)

- Group: xprs-dev: analysis, TDD, implementation, review and merge request
- Skill number: DV-04
- Type: Adapter
- Status: draft v0.1, to be refined in the build and feedback iterations

## 1. Description

Finds how similar features are already built here, to copy the style.

Human gate: Human gates after analysis and plan, and at merge request review. TDD is mandatory: no implementation without a failing test first.

## 2. Inputs and outputs

- Inputs: feature description, repository
- Outputs: examples of similar existing code and the conventions to follow

## 3. Tools and permissions

Read and write inside the run workspace. Shell limited to the stack adapter's allow-listed build, test, lint and scan commands. Git on feature branches only; no push to protected branches. Jira and merge request through the MCP gateway.

All tool calls pass through the guardrails and the MCP gateway. Anything not listed here is denied.

## 4. Tech stack

Skill logic is common. Commands come from the stack adapter (detect, build and test, coverage, mutation, lint, scan arguments). Supported by adapters for Java (Maven, Gradle), Angular and TypeScript, .NET, Go and Python; add others by adding an adapter.

## 5. Dependencies

SH-08 application-profile-load; SH-10 artifact-handoff-read; SH-09 artifact-handoff-write; SH-19 audit-trail-emit. Platform services: Guardrails, LLM Gateway, MCP Gateway, Context Setting, Audit and Observability apply automatically. SH-07 repo-context-discovery and SH-29 skill-switch-selection choose the adapter.

## 6. Templates

Analysis note, task plan, test case list, commit message, merge request description, changelog entry.

## 7. Validation

Tests written first and seen failing; all tests green; coverage and mutation targets met where required; lint clean; no secrets in diff; evidence attached to the merge request. Tested on a sample repository for each supported stack.

## 8. Reuse and enhancement

Skill logic stays shared. To support a new tech stack, add a stack adapter rather than editing this skill. Report adapter gaps through SH-23.

## How to run

1. Load the application profile (SH-08) and read the input artifacts.
2. Do the work described above, within the permissions listed.
3. Write the output artifact in its schema (SH-09) and request the human gate where one applies (SH-11).
4. Emit the audit event (SH-19). If a guardrail returns escalate or block, stop and follow SH-20.
