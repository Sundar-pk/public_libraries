---
name: code-self-review
description: "Reviews its own diff against standards, design and acceptance criteria."
---

# code-self-review (DV-45)

- Group: xprs-dev: analysis, TDD, implementation, review and merge request
- Skill number: DV-45
- Type: Core
- Status: draft v0.1, to be refined in the build and feedback iterations

## 1. Description

Reviews its own diff against standards, design and acceptance criteria.

Human gate: Human gates after analysis and plan, and at merge request review. TDD is mandatory: no implementation without a failing test first.

## 2. Inputs and outputs

- Inputs: diff, standards, acceptance criteria
- Outputs: self-review findings and fixes

## 3. Tools and permissions

Read and write inside the run workspace. Shell limited to the stack adapter's allow-listed build, test, lint and scan commands. Git on feature branches only; no push to protected branches. Jira and merge request through the MCP gateway.

All tool calls pass through the guardrails and the MCP gateway. Anything not listed here is denied.

## 4. Tech stack

Language and stack neutral. Works on documents, tickets, artifacts and tool results. No stack adapter needed.

## 5. Dependencies

SH-08 application-profile-load; SH-10 artifact-handoff-read; SH-09 artifact-handoff-write; SH-19 audit-trail-emit. Platform services: Guardrails, LLM Gateway, MCP Gateway, Context Setting, Audit and Observability apply automatically.

## 6. Templates

Analysis note, task plan, test case list, commit message, merge request description, changelog entry.

## 7. Validation

Tests written first and seen failing; all tests green; coverage and mutation targets met where required; lint clean; no secrets in diff; evidence attached to the merge request.

## 8. Reuse and enhancement

Shared by all applications. Parameterise through the application profile; do not copy. Improve once here and every factory benefits.

## How to run

1. Load the application profile (SH-08) and read the input artifacts.
2. Do the work described above, within the permissions listed.
3. Write the output artifact in its schema (SH-09) and request the human gate where one applies (SH-11).
4. Emit the audit event (SH-19). If a guardrail returns escalate or block, stop and follow SH-20.
