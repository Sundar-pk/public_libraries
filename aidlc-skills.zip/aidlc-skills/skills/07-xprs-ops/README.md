# xprs-ops: monitoring, incident, problem and support

36 skills.

| No | Skill | Description | Type |
| --- | --- | --- | --- |
| OP-01 | [service-catalogue-and-runbook-lookup](service-catalogue-and-runbook-lookup/SKILL.md) | Finds the service owner, dependencies and runbook | Core |
| OP-02 | [slo-and-alert-definition](slo-and-alert-definition/SKILL.md) | Defines SLOs, error budgets and alert rules | Core |
| OP-03 | [dashboard-generation](dashboard-generation/SKILL.md) | Builds dashboards for golden signals and business metrics | Adapter |
| OP-04 | [log-query-and-search](log-query-and-search/SKILL.md) | Queries logs with the right filters and time window | Adapter |
| OP-05 | [metric-query-and-trend](metric-query-and-trend/SKILL.md) | Reads metrics and detects trend changes | Adapter |
| OP-06 | [distributed-trace-analysis](distributed-trace-analysis/SKILL.md) | Follows a request across services to find the slow or failing hop | Adapter |
| OP-07 | [anomaly-detection](anomaly-detection/SKILL.md) | Flags unusual behaviour against a learned baseline | Core |
| OP-08 | [alert-noise-reduction](alert-noise-reduction/SKILL.md) | Groups, deduplicates and tunes noisy alerts | Core |
| OP-09 | [alert-triage](alert-triage/SKILL.md) | Classifies an alert, checks recent changes and decides who to call | Core |
| OP-10 | [incident-declaration](incident-declaration/SKILL.md) | Opens an incident with severity, impact and commander | Core |
| OP-11 | [incident-timeline-builder](incident-timeline-builder/SKILL.md) | Builds a timeline from alerts, deployments and chat | Core |
| OP-12 | [impact-assessment](impact-assessment/SKILL.md) | Estimates affected users, transactions and revenue | Core |
| OP-13 | [change-correlation](change-correlation/SKILL.md) | Links the incident to recent deployments and config changes | Core |
| OP-14 | [hypothesis-generation-and-testing](hypothesis-generation-and-testing/SKILL.md) | Lists likely causes and tests each with evidence | Core |
| OP-15 | [known-error-matching](known-error-matching/SKILL.md) | Matches symptoms to known errors and past incidents | Core |
| OP-16 | [runbook-step-execution](runbook-step-execution/SKILL.md) | Executes approved runbook steps with a gate for risky ones | Adapter |
| OP-17 | [safe-restart-and-scaling](safe-restart-and-scaling/SKILL.md) | Restarts or scales a service within pre-approved limits | Adapter |
| OP-18 | [rollback-recommendation](rollback-recommendation/SKILL.md) | Recommends rollback or feature-flag off with evidence | Core |
| OP-19 | [incident-communication-draft](incident-communication-draft/SKILL.md) | Drafts updates for stakeholders and status pages | Core |
| OP-20 | [escalation-routing](escalation-routing/SKILL.md) | Routes to the right on-call team and tracks acknowledgement | Core |
| OP-21 | [incident-resolution-record](incident-resolution-record/SKILL.md) | Records the fix, verification and closure criteria | Core |
| OP-22 | [post-incident-review](post-incident-review/SKILL.md) | Writes the blameless review: cause, detection, response, actions | Core |
| OP-23 | [corrective-action-tracking](corrective-action-tracking/SKILL.md) | Tracks follow-up actions to closure | Core |
| OP-24 | [problem-record-creation](problem-record-creation/SKILL.md) | Opens a problem record from repeated incidents | Core |
| OP-25 | [problem-root-cause-analysis](problem-root-cause-analysis/SKILL.md) | Finds the underlying cause across incidents | Core |
| OP-26 | [defect-ticket-from-incident](defect-ticket-from-incident/SKILL.md) | Creates a development defect with evidence for the Quality Defect loop | Core |
| OP-27 | [support-ticket-triage](support-ticket-triage/SKILL.md) | Classifies user tickets, finds duplicates and routes them | Core |
| OP-28 | [support-answer-from-knowledge](support-answer-from-knowledge/SKILL.md) | Drafts replies from the knowledge base with sources | Core |
| OP-29 | [knowledge-article-creation](knowledge-article-creation/SKILL.md) | Turns resolved cases into knowledge articles | Core |
| OP-30 | [user-impact-communication](user-impact-communication/SKILL.md) | Writes plain-language notices for planned work and outages | Core |
| OP-31 | [capacity-and-cost-monitoring](capacity-and-cost-monitoring/SKILL.md) | Tracks usage, saturation and cloud cost against budget | Adapter |
| OP-32 | [certificate-and-secret-expiry-watch](certificate-and-secret-expiry-watch/SKILL.md) | Warns before certificates, tokens and keys expire | Adapter |
| OP-33 | [patching-and-vulnerability-ops](patching-and-vulnerability-ops/SKILL.md) | Plans patching for hosts, runtimes and images | Adapter |
| OP-34 | [backup-and-restore-verification](backup-and-restore-verification/SKILL.md) | Checks backups exist and restores work | Adapter |
| OP-35 | [disaster-recovery-drill](disaster-recovery-drill/SKILL.md) | Plans and records DR exercises against RTO and RPO | Core |
| OP-36 | [production-feedback-to-backlog](production-feedback-to-backlog/SKILL.md) | Sends operational findings back to xprs-ba and xprs-mod as backlog items | Core |
