---
name: change-correlation
description: "Links the incident to recent deployments and config changes."
---

# change-correlation (OP-13)

- Group: xprs-ops: monitoring, incident, problem and support
- Skill number: OP-13
- Type: Core
- Status: draft v0.1, to be refined in the build and feedback iterations

## 1. Description

Links the incident to recent deployments and config changes.

Human gate: Any action that changes production waits for a human gate. Read-only diagnosis needs none.

## 2. Inputs and outputs

- Inputs: incident, change history
- Outputs: recent deployments and config changes linked to the incident

## 3. Tools and permissions

Read on logs, metrics, traces and runbooks through the MCP gateway. Change actions only through approved runbook steps. Ticket and chat access through the MCP gateway.

All tool calls pass through the guardrails and the MCP gateway. Anything not listed here is denied.

## 4. Tech stack

Language and stack neutral. Works on documents, tickets, artifacts and tool results. No stack adapter needed.

## 5. Dependencies

SH-08 application-profile-load; SH-10 artifact-handoff-read; SH-09 artifact-handoff-write; SH-19 audit-trail-emit. Platform services: Guardrails, LLM Gateway, MCP Gateway, Context Setting, Audit and Observability apply automatically.

## 6. Templates

Incident record, timeline, post-incident review, problem record, knowledge article, status update.

## 7. Validation

Claims backed by log, metric or trace evidence; timeline matches source events; no production change without gate; follow-up actions have owners.

## 8. Reuse and enhancement

Shared by all applications. Parameterise through the application profile; do not copy. Improve once here and every factory benefits.

## How to run

1. Load the application profile (SH-08) and read the input artifacts.
2. Do the work described above, within the permissions listed.
3. Write the output artifact in its schema (SH-09) and request the human gate where one applies (SH-11).
4. Emit the audit event (SH-19). If a guardrail returns escalate or block, stop and follow SH-20.
