---
name: metric-query-and-trend
description: "Reads metrics and detects trend changes."
---

# metric-query-and-trend (OP-05)

- Group: xprs-ops: monitoring, incident, problem and support
- Skill number: OP-05
- Type: Adapter
- Status: draft v0.1, to be refined in the build and feedback iterations

## 1. Description

Reads metrics and detects trend changes.

Human gate: Any action that changes production waits for a human gate. Read-only diagnosis needs none.

## 2. Inputs and outputs

- Inputs: metric, time window
- Outputs: metric values and trend change

## 3. Tools and permissions

Read on logs, metrics, traces and runbooks through the MCP gateway. Change actions only through approved runbook steps. Ticket and chat access through the MCP gateway.

All tool calls pass through the guardrails and the MCP gateway. Anything not listed here is denied.

## 4. Tech stack

Skill logic is common. Commands come from the stack adapter (detect, build and test, coverage, mutation, lint, scan arguments). Supported by adapters for Java (Maven, Gradle), Angular and TypeScript, .NET, Go and Python; add others by adding an adapter.

## 5. Dependencies

SH-08 application-profile-load; SH-10 artifact-handoff-read; SH-09 artifact-handoff-write; SH-19 audit-trail-emit. Platform services: Guardrails, LLM Gateway, MCP Gateway, Context Setting, Audit and Observability apply automatically. SH-07 repo-context-discovery and SH-29 skill-switch-selection choose the adapter.

## 6. Templates

Incident record, timeline, post-incident review, problem record, knowledge article, status update.

## 7. Validation

Claims backed by log, metric or trace evidence; timeline matches source events; no production change without gate; follow-up actions have owners. Tested on a sample repository for each supported stack.

## 8. Reuse and enhancement

Skill logic stays shared. To support a new tech stack, add a stack adapter rather than editing this skill. Report adapter gaps through SH-23.

## How to run

1. Load the application profile (SH-08) and read the input artifacts.
2. Do the work described above, within the permissions listed.
3. Write the output artifact in its schema (SH-09) and request the human gate where one applies (SH-11).
4. Emit the audit event (SH-19). If a guardrail returns escalate or block, stop and follow SH-20.
