---
name: flaky-test-quarantine
description: "Quarantines unstable tests with an owner and expiry."
---

# flaky-test-quarantine (QA-28)

- Group: xprs-qa: testing, defects and quality evidence
- Skill number: QA-28
- Type: Adapter
- Status: draft v0.1, to be refined in the build and feedback iterations

## 1. Description

Quarantines unstable tests with an owner and expiry.

Human gate: QA lead approves the test plan and the go or no-go recommendation. Business users sign off UAT.

## 2. Inputs and outputs

- Inputs: flaky test list
- Outputs: quarantine record with owner and expiry

## 3. Tools and permissions

Read on code and requirements. Write tests and reports inside the workspace. Shell limited to allow-listed test runners. Defect create and update in Jira through the MCP gateway.

All tool calls pass through the guardrails and the MCP gateway. Anything not listed here is denied.

## 4. Tech stack

Skill logic is common. Commands come from the stack adapter (detect, build and test, coverage, mutation, lint, scan arguments). Supported by adapters for Java (Maven, Gradle), Angular and TypeScript, .NET, Go and Python; add others by adding an adapter.

## 5. Dependencies

SH-08 application-profile-load; SH-10 artifact-handoff-read; SH-09 artifact-handoff-write; SH-19 audit-trail-emit. Platform services: Guardrails, LLM Gateway, MCP Gateway, Context Setting, Audit and Observability apply automatically. SH-07 repo-context-discovery and SH-29 skill-switch-selection choose the adapter.

## 6. Templates

Test plan, test case, test summary report, defect report, UAT sign-off sheet.

## 7. Validation

Every test traces to a requirement; results normalised to one format; flaky tests flagged; gate rules evaluated from data, not opinion. Tested on a sample repository for each supported stack.

## 8. Reuse and enhancement

Skill logic stays shared. To support a new tech stack, add a stack adapter rather than editing this skill. Report adapter gaps through SH-23.

## How to run

1. Load the application profile (SH-08) and read the input artifacts.
2. Do the work described above, within the permissions listed.
3. Write the output artifact in its schema (SH-09) and request the human gate where one applies (SH-11).
4. Emit the audit event (SH-19). If a guardrail returns escalate or block, stop and follow SH-20.
