# xprs-qa: testing, defects and quality evidence

37 skills.

| No | Skill | Description | Type |
| --- | --- | --- | --- |
| QA-01 | [requirement-testability-review](requirement-testability-review/SKILL.md) | Checks requirements and criteria can be tested | Core |
| QA-02 | [test-plan-compose](test-plan-compose/SKILL.md) | Builds the test plan from the strategy: scope, levels, entry and exit criteria | Core |
| QA-03 | [test-case-design](test-case-design/SKILL.md) | Designs cases using equivalence, boundary and decision-table techniques | Core |
| QA-04 | [test-scenario-from-acceptance](test-scenario-from-acceptance/SKILL.md) | Converts acceptance criteria to test scenarios | Core |
| QA-05 | [negative-and-abuse-test-design](negative-and-abuse-test-design/SKILL.md) | Designs invalid input, misuse and permission tests | Core |
| QA-06 | [test-data-design](test-data-design/SKILL.md) | Specifies test data needs, masking and refresh | Core |
| QA-07 | [test-data-generation](test-data-generation/SKILL.md) | Generates synthetic data that keeps referential integrity | Adapter |
| QA-08 | [test-environment-readiness](test-environment-readiness/SKILL.md) | Checks environments, versions, configs and stubs before a cycle | Core |
| QA-09 | [regression-suite-selection](regression-suite-selection/SKILL.md) | Selects regression tests by code change and risk | Adapter |
| QA-10 | [test-impact-analysis](test-impact-analysis/SKILL.md) | Maps changed code to the tests that must run | Adapter |
| QA-11 | [api-test-automation](api-test-automation/SKILL.md) | Writes and runs API tests | Adapter |
| QA-12 | [ui-test-automation](ui-test-automation/SKILL.md) | Writes and runs browser or UI tests | Adapter |
| QA-13 | [mobile-test-automation](mobile-test-automation/SKILL.md) | Writes and runs mobile app tests | Adapter |
| QA-14 | [integration-test-execution](integration-test-execution/SKILL.md) | Runs system integration tests across services | Adapter |
| QA-15 | [contract-test-verification](contract-test-verification/SKILL.md) | Verifies provider and consumer contracts in the pipeline | Adapter |
| QA-16 | [end-to-end-journey-test](end-to-end-journey-test/SKILL.md) | Runs business journeys across systems | Adapter |
| QA-17 | [performance-test-design](performance-test-design/SKILL.md) | Designs load, stress and soak profiles from the performance budget | Core |
| QA-18 | [performance-test-execution](performance-test-execution/SKILL.md) | Runs load tests and collects results | Adapter |
| QA-19 | [performance-result-analysis](performance-result-analysis/SKILL.md) | Finds bottlenecks and compares with the budget and baseline | Core |
| QA-20 | [resilience-and-chaos-test](resilience-and-chaos-test/SKILL.md) | Tests failure handling, failover and recovery | Adapter |
| QA-21 | [accessibility-test](accessibility-test/SKILL.md) | Runs automated and checklist accessibility checks | Adapter |
| QA-22 | [security-functional-test](security-functional-test/SKILL.md) | Tests authentication, authorisation and input handling | Adapter |
| QA-23 | [data-migration-validation](data-migration-validation/SKILL.md) | Reconciles migrated data against the source | Adapter |
| QA-24 | [exploratory-test-charter](exploratory-test-charter/SKILL.md) | Writes charters for human exploratory sessions | Core |
| QA-25 | [uat-pack-preparation](uat-pack-preparation/SKILL.md) | Prepares UAT scripts, data and sign-off sheet for business users | Core |
| QA-26 | [test-execution-orchestration](test-execution-orchestration/SKILL.md) | Runs suites in order, retries safely and collects results | Adapter |
| QA-27 | [test-result-normalisation](test-result-normalisation/SKILL.md) | Converts any framework's output to one result format | Adapter |
| QA-28 | [flaky-test-quarantine](flaky-test-quarantine/SKILL.md) | Quarantines unstable tests with an owner and expiry | Adapter |
| QA-29 | [defect-logging](defect-logging/SKILL.md) | Creates a defect with steps, evidence, severity and links | Core |
| QA-30 | [defect-duplicate-detection](defect-duplicate-detection/SKILL.md) | Finds existing defects that match | Core |
| QA-31 | [defect-triage-and-severity](defect-triage-and-severity/SKILL.md) | Proposes severity, priority and owner | Core |
| QA-32 | [defect-root-cause-analysis](defect-root-cause-analysis/SKILL.md) | Traces a defect to the change or requirement that caused it | Core |
| QA-33 | [defect-reproduction](defect-reproduction/SKILL.md) | Builds a minimal reproduction from logs and steps | Adapter |
| QA-34 | [defect-fix-verification](defect-fix-verification/SKILL.md) | Re-tests a fix and runs the related regression | Adapter |
| QA-35 | [quality-gate-evaluation](quality-gate-evaluation/SKILL.md) | Evaluates coverage, mutation score, defect counts and pass rate against gate rules | Core |
| QA-36 | [test-summary-and-release-recommendation](test-summary-and-release-recommendation/SKILL.md) | Writes the test summary with evidence and a go or no-go recommendation | Core |
| QA-37 | [uat-coordination](uat-coordination/SKILL.md) | Orchestrates user acceptance testing stages: schedules testers, collects feedback and tracks sign-off | Core |
