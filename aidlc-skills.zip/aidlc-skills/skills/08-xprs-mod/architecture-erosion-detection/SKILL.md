---
name: architecture-erosion-detection
description: "Finds drift from the intended architecture."
---

# architecture-erosion-detection (MD-10)

- Group: xprs-mod: modernisation, technical debt and continuous improvement
- Skill number: MD-10
- Type: Adapter
- Status: draft v0.1, to be refined in the build and feedback iterations

## 1. Description

Finds drift from the intended architecture.

Human gate: Architect approves strategy and target design. Owner approves each migration slice before cutover.

## 2. Inputs and outputs

- Inputs: code, intended architecture
- Outputs: architecture drift findings

## 3. Tools and permissions

Read on repository and runtime data. Write inside a working branch only. Shell limited to allow-listed analysis, build and test commands. Tickets through the MCP gateway.

All tool calls pass through the guardrails and the MCP gateway. Anything not listed here is denied.

## 4. Tech stack

Skill logic is common. Commands come from the stack adapter (detect, build and test, coverage, mutation, lint, scan arguments). Supported by adapters for Java (Maven, Gradle), Angular and TypeScript, .NET, Go and Python; add others by adding an adapter.

## 5. Dependencies

SH-08 application-profile-load; SH-10 artifact-handoff-read; SH-09 artifact-handoff-write; SH-19 audit-trail-emit. Platform services: Guardrails, LLM Gateway, MCP Gateway, Context Setting, Audit and Observability apply automatically. SH-07 repo-context-discovery and SH-29 skill-switch-selection choose the adapter.

## 6. Templates

Debt register, modernisation roadmap, migration plan, characterization test set, parity report.

## 7. Validation

Behaviour unchanged (tests or parity report); each change small and reversible; debt items carry evidence and score; benefits measured against the case. Tested on a sample repository for each supported stack.

## 8. Reuse and enhancement

Skill logic stays shared. To support a new tech stack, add a stack adapter rather than editing this skill. Report adapter gaps through SH-23.

## How to run

1. Load the application profile (SH-08) and read the input artifacts.
2. Do the work described above, within the permissions listed.
3. Write the output artifact in its schema (SH-09) and request the human gate where one applies (SH-11).
4. Emit the audit event (SH-19). If a guardrail returns escalate or block, stop and follow SH-20.
