# xprs-mod: modernisation, technical debt and continuous improvement

34 skills.

| No | Skill | Description | Type |
| --- | --- | --- | --- |
| MD-01 | [application-inventory-and-profiling](application-inventory-and-profiling/SKILL.md) | Profiles an application: size, languages, age, owners, usage | Core |
| MD-02 | [codebase-reverse-engineering](codebase-reverse-engineering/SKILL.md) | Reads legacy code and writes down what it does | Adapter |
| MD-03 | [business-rule-recovery](business-rule-recovery/SKILL.md) | Extracts business rules from code, stored procedures and configs | Adapter |
| MD-04 | [legacy-documentation-generation](legacy-documentation-generation/SKILL.md) | Generates architecture and API documentation from code | Adapter |
| MD-05 | [dependency-and-eol-assessment](dependency-and-eol-assessment/SKILL.md) | Finds end-of-life runtimes, frameworks and libraries | Adapter |
| MD-06 | [technical-debt-detection](technical-debt-detection/SKILL.md) | Finds duplication, complexity, dead code and design smells | Adapter |
| MD-07 | [technical-debt-quantification](technical-debt-quantification/SKILL.md) | Converts debt to effort and risk with a score per item | Core |
| MD-08 | [debt-prioritisation](debt-prioritisation/SKILL.md) | Ranks debt by risk, change frequency and business value | Core |
| MD-09 | [debt-backlog-creation](debt-backlog-creation/SKILL.md) | Creates debt tickets with evidence and proposed fix | Core |
| MD-10 | [architecture-erosion-detection](architecture-erosion-detection/SKILL.md) | Finds drift from the intended architecture | Adapter |
| MD-11 | [test-gap-analysis](test-gap-analysis/SKILL.md) | Finds critical code with no tests | Adapter |
| MD-12 | [characterization-test-generation](characterization-test-generation/SKILL.md) | Writes tests that capture current behaviour before changing it | Adapter |
| MD-13 | [safe-refactoring-plan](safe-refactoring-plan/SKILL.md) | Plans small, reversible refactoring steps | Adapter |
| MD-14 | [automated-refactoring-execution](automated-refactoring-execution/SKILL.md) | Applies refactorings with tests green at every step | Adapter |
| MD-15 | [dead-code-removal](dead-code-removal/SKILL.md) | Removes unused code after usage evidence | Adapter |
| MD-16 | [dependency-upgrade-planning](dependency-upgrade-planning/SKILL.md) | Plans library and framework upgrades in a safe order | Adapter |
| MD-17 | [dependency-upgrade-execution](dependency-upgrade-execution/SKILL.md) | Upgrades versions, fixes breakages and runs tests | Adapter |
| MD-18 | [language-and-runtime-upgrade](language-and-runtime-upgrade/SKILL.md) | Moves to a newer language or runtime version | Adapter |
| MD-19 | [modernisation-strategy-selection](modernisation-strategy-selection/SKILL.md) | Chooses retain, rehost, replatform, refactor, replace or retire | Core |
| MD-20 | [target-architecture-proposal](target-architecture-proposal/SKILL.md) | Proposes the target design and migration path | Core |
| MD-21 | [strangler-slice-identification](strangler-slice-identification/SKILL.md) | Finds the first slice that can be moved safely | Core |
| MD-22 | [code-migration-translation](code-migration-translation/SKILL.md) | Translates code between languages or frameworks with a parity check | Adapter |
| MD-23 | [data-store-migration](data-store-migration/SKILL.md) | Plans and verifies a move between databases | Adapter |
| MD-24 | [behaviour-parity-verification](behaviour-parity-verification/SKILL.md) | Compares old and new system outputs on the same inputs | Adapter |
| MD-25 | [cloud-readiness-assessment](cloud-readiness-assessment/SKILL.md) | Checks twelve-factor and container readiness | Core |
| MD-26 | [containerisation](containerisation/SKILL.md) | Creates container images and manifests for the application | Adapter |
| MD-27 | [performance-profiling-and-tuning](performance-profiling-and-tuning/SKILL.md) | Finds hotspots and proposes fixes | Adapter |
| MD-28 | [cost-optimisation](cost-optimisation/SKILL.md) | Finds over-provisioned or idle resources | Core |
| MD-29 | [modernisation-roadmap](modernisation-roadmap/SKILL.md) | Builds the multi-quarter roadmap with effort and benefit | Core |
| MD-30 | [benefits-tracking](benefits-tracking/SKILL.md) | Measures value delivered against the business case | Core |
| MD-31 | [skill-usage-analytics](skill-usage-analytics/SKILL.md) | Reports which skills are used, by whom and with what outcome | Core |
| MD-32 | [skill-quality-review](skill-quality-review/SKILL.md) | Reviews a skill's results and feedback and proposes changes | Core |
| MD-33 | [skill-gap-identification](skill-gap-identification/SKILL.md) | Finds repeated manual work that should become a skill | Core |
| MD-34 | [portfolio-standardisation-report](portfolio-standardisation-report/SKILL.md) | Compares the 400 applications on practices, tooling and skill adoption | Core |
