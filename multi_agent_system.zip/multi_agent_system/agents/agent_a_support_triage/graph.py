from langgraph.graph import StateGraph, START, END

from agents.agent_a_support_triage.state import SupportState
from agents.agent_a_support_triage.nodes import (
    classify_intent_node,
    retrieve_kb_node,
    draft_reply_node,
    escalate_to_specialist_node,
    resolve_at_tier1_node,
    route_after_draft,
)


def build_graph():
    graph = StateGraph(SupportState)

    graph.add_node("classify_intent", classify_intent_node)
    graph.add_node("retrieve_kb", retrieve_kb_node)
    graph.add_node("draft_reply", draft_reply_node)
    graph.add_node("escalate", escalate_to_specialist_node)   # <- calls Agent B inside
    graph.add_node("resolve", resolve_at_tier1_node)

    graph.add_edge(START, "classify_intent")
    graph.add_edge("classify_intent", "retrieve_kb")
    graph.add_edge("retrieve_kb", "draft_reply")
    graph.add_conditional_edges(
        "draft_reply", route_after_draft,
        {"escalate": "escalate", "resolve": "resolve"},
    )
    graph.add_edge("escalate", END)
    graph.add_edge("resolve", END)

    return graph.compile()


app = build_graph()
