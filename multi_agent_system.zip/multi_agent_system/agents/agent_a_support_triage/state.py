from typing import TypedDict, Optional, List, Dict
from typing_extensions import Annotated
import operator


class SupportState(TypedDict):
    customer_message: str
    intent: Optional[str]
    entities: Optional[Dict]
    sentiment: Optional[str]
    kb_matches: Optional[List[Dict]]
    draft_reply: Optional[str]
    confidence: Optional[float]
    escalated: Optional[bool]
    final_response: Optional[str]
    resolved_by: Optional[str]
    # Every node appends here instead of overwriting -- by the end this
    # is a full audit trail across BOTH agents, since Agent B's trace
    # gets folded in too when it's called.
    trace: Annotated[List[str], operator.add]
