"""
nodes.py -- Agent A: Tier-1 Support Triage

Three specialist nodes (intent classification, KB retrieval, reply
drafting), each pinned to a different internal model via
config/model_registry.py. The interesting one is escalate_to_specialist_node:
this is where Agent A DIRECTLY calls Agent B's already-compiled graph --
a plain Python function call, no third orchestrator file involved.
"""
import json

from gateway.llm_client import call_llm, embed, safe_json
from agents.agent_b_specialist_escalation.graph import app as agent_b_app
from agents.agent_b_specialist_escalation.state import EscalationState

ESCALATION_CONFIDENCE_THRESHOLD = 50


def classify_intent_node(state: dict) -> dict:
    prompt = (
        "Classify this customer message's intent and extract key entities. "
        'Respond ONLY with JSON: {"intent": str, "entities": {}, "sentiment": "positive"|"neutral"|"negative"}\n\n'
        f"Message: {state['customer_message']}"
    )
    raw = call_llm("intent_classifier", "You are a support triage classifier.", prompt)
    result = safe_json(raw)
    return {
        "intent": result.get("intent"),
        "entities": result.get("entities", {}),
        "sentiment": result.get("sentiment"),
        "trace": [f"[Agent A / classify_intent / mistral-small-2506-ITG] intent={result.get('intent')} sentiment={result.get('sentiment')}"],
    }


def retrieve_kb_node(state: dict) -> dict:
    # Embed the customer message, then in a real system do a vector
    # search against your KB index with it. Mocked here as two
    # plausible hits so the rest of the pipeline has something to use.
    _ = embed("kb_retriever", state["customer_message"])
    kb_matches = [
        {"article": "KB-104: Duplicate charge disputes", "score": 0.86},
        {"article": "KB-212: Refund timelines", "score": 0.71},
    ]
    return {
        "kb_matches": kb_matches,
        "trace": [f"[Agent A / retrieve_kb / bge-large-en-v1.5-ITG] top match={kb_matches[0]['article']} score={kb_matches[0]['score']}"],
    }


def draft_reply_node(state: dict) -> dict:
    prompt = (
        "Draft a first-response reply to this customer, using the retrieved KB articles as context. "
        "Also self-rate your confidence (0-100) that this reply fully resolves the issue without a specialist. "
        'Respond ONLY with JSON: {"draft_reply": str, "confidence": int}\n\n'
        f"Message: {state['customer_message']}\nIntent: {state['intent']}\nKB matches: {json.dumps(state['kb_matches'])}"
    )
    raw = call_llm("reply_drafter", "You are a tier-1 support agent.", prompt)
    result = safe_json(raw)
    return {
        "draft_reply": result.get("draft_reply"),
        "confidence": result.get("confidence", 50),
        "trace": [f"[Agent A / draft_reply / qwen3.6-27b] confidence={result.get('confidence')}"],
    }


def escalate_to_specialist_node(state: dict) -> dict:
    """The agent-to-agent handoff. Agent A builds Agent B's input state
    from its own state, then invokes Agent B's compiled graph directly --
    agent_b_app.invoke(...) is an ordinary function call, exactly like
    calling any other Python function. Agent A owns both the decision to
    escalate (see route_after_draft below) and the handoff itself."""
    agent_b_input: EscalationState = {
        "customer_message": state["customer_message"],
        "tier1_intent": state["intent"],
        "tier1_draft": state["draft_reply"],
        "tier1_confidence": state["confidence"],
        "kb_matches": state["kb_matches"],
        "trace": [],
    }
    result = agent_b_app.invoke(agent_b_input)

    return {
        "escalated": True,
        "final_response": result["resolution"],
        "resolved_by": "specialist (Agent B)",
        "trace": [
            f"[Agent A / escalate] confidence {state['confidence']} < {ESCALATION_CONFIDENCE_THRESHOLD} "
            f"(or negative sentiment) -- handing off to Agent B"
        ] + result["trace"],
    }


def resolve_at_tier1_node(state: dict) -> dict:
    return {
        "escalated": False,
        "final_response": state["draft_reply"],
        "resolved_by": "tier-1 (Agent A)",
        "trace": ["[Agent A / resolve] confidence sufficient -- resolved without escalation"],
    }


def route_after_draft(state: dict) -> str:
    low_confidence = (state.get("confidence") or 0) < ESCALATION_CONFIDENCE_THRESHOLD
    negative_sentiment = state.get("sentiment") == "negative"
    return "escalate" if (low_confidence or negative_sentiment) else "resolve"
