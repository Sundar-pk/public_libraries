"""
nodes.py -- Agent B: Specialist Escalation

Entirely separate from Agent A: its own state, its own three nodes,
each on a different internal model. Agent B has no idea Agent A exists --
it just takes an EscalationState and returns one. That's what makes it
independently buildable, testable, and reusable (see main.py running
Agent A only; Agent B is only ever invoked through the handoff).
"""
from gateway.llm_client import call_llm, safe_json


def tag_severity_node(state: dict) -> dict:
    prompt = (
        "Tag the severity of this escalated support case (low/medium/high) and give a one-sentence reason. "
        'Respond ONLY with JSON: {"severity": str, "reason": str}\n\n'
        f"Message: {state['customer_message']}\n"
        f"Tier-1 intent: {state['tier1_intent']}\nTier-1 confidence: {state['tier1_confidence']}"
    )
    raw = call_llm("severity_tagger", "You are a support escalation triage specialist.", prompt)
    result = safe_json(raw)
    return {
        "severity": result.get("severity"),
        "trace": [f"[Agent B / tag_severity / mistral-small-4-ITG] severity={result.get('severity')} -- {result.get('reason')}"],
    }


def root_cause_node(state: dict) -> dict:
    prompt = (
        f"Do a root-cause analysis for this escalated case. Tier-1 already tried: "
        f"'{state['tier1_draft']}' but couldn't resolve it (confidence {state['tier1_confidence']}). "
        'Respond ONLY with JSON: {"root_cause": str}\n\n'
        f"Message: {state['customer_message']}"
    )
    raw = call_llm("root_cause_analyst", "You are a senior support specialist doing root-cause analysis.", prompt)
    result = safe_json(raw)
    return {
        "root_cause": result.get("root_cause"),
        "trace": [f"[Agent B / root_cause / gpt-oss-120b-ITG] {result.get('root_cause')}"],
    }


def draft_resolution_node(state: dict) -> dict:
    prompt = (
        "Draft the final resolution for this customer, given the root cause. "
        'Respond ONLY with JSON: {"resolution": str}\n\n'
        f"Root cause: {state['root_cause']}\nSeverity: {state['severity']}\nMessage: {state['customer_message']}"
    )
    raw = call_llm("resolution_drafter", "You are a senior support specialist writing the final resolution.", prompt)
    result = safe_json(raw)
    return {
        "resolution": result.get("resolution"),
        "trace": [f"[Agent B / draft_resolution / qwen-latest] {result.get('resolution')}"],
    }
