from typing import TypedDict, Optional, List, Dict
from typing_extensions import Annotated
import operator


class EscalationState(TypedDict):
    # Inputs handed over by Agent A at the point of escalation
    customer_message: str
    tier1_intent: Optional[str]
    tier1_draft: Optional[str]
    tier1_confidence: Optional[float]
    kb_matches: Optional[List[Dict]]
    # Filled in by Agent B's own nodes
    severity: Optional[str]
    root_cause: Optional[str]
    resolution: Optional[str]
    trace: Annotated[List[str], operator.add]
