from langgraph.graph import StateGraph, START, END

from agents.agent_b_specialist_escalation.state import EscalationState
from agents.agent_b_specialist_escalation.nodes import (
    tag_severity_node,
    root_cause_node,
    draft_resolution_node,
)


def build_graph():
    graph = StateGraph(EscalationState)

    graph.add_node("tag_severity", tag_severity_node)
    graph.add_node("root_cause", root_cause_node)
    graph.add_node("draft_resolution", draft_resolution_node)

    graph.add_edge(START, "tag_severity")
    graph.add_edge("tag_severity", "root_cause")
    graph.add_edge("root_cause", "draft_resolution")
    graph.add_edge("draft_resolution", END)

    return graph.compile()


# Compiled once, at import time -- this is the exact object Agent A
# imports and calls directly in escalate_to_specialist_node.
app = build_graph()
