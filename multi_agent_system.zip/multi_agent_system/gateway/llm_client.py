"""
llm_client.py

The ONE HTTP client shared by every node in both agents. A node calls
call_llm(role, ...) or embed(role, ...) -- never requests.post directly,
and never a literal model id. Which real model answers a role lives in
config/model_registry.py, not here.
"""
import json
import re

import requests

from config.model_registry import resolve, USE_MOCK_LLM


def call_llm(role: str, system_prompt: str, user_prompt: str,
             *, temperature: float = 0.0, max_tokens: int = 800) -> str:
    """Chat-completion call, routed by role -> registry model."""
    cfg = resolve(role)

    if USE_MOCK_LLM:
        return _mock_chat_response(role, user_prompt)

    url = f"{cfg['base_url']}/chat/completions"
    headers = {"Authorization": f"Bearer {cfg['api_key']}", "Content-Type": "application/json"}
    payload = {
        "model": cfg["model_id"],
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        "temperature": temperature,
        "max_tokens": max_tokens,
    }
    resp = requests.post(url, headers=headers, json=payload, timeout=30)
    resp.raise_for_status()
    return resp.json()["choices"][0]["message"]["content"]


def embed(role: str, text: str) -> list:
    """Embedding call, routed by role -> registry embedding model."""
    cfg = resolve(role)

    if USE_MOCK_LLM:
        return _mock_embedding(text)

    url = f"{cfg['base_url']}/embeddings"
    headers = {"Authorization": f"Bearer {cfg['api_key']}", "Content-Type": "application/json"}
    payload = {"model": cfg["model_id"], "input": text}
    resp = requests.post(url, headers=headers, json=payload, timeout=30)
    resp.raise_for_status()
    return resp.json()["data"][0]["embedding"]


def safe_json(raw_text: str) -> dict:
    """Model output is occasionally wrapped in ```json fences -- strip
    that before parsing."""
    cleaned = re.sub(r"^```(json)?|```$", "", raw_text.strip(), flags=re.MULTILINE).strip()
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", cleaned, flags=re.DOTALL)
        if match:
            return json.loads(match.group(0))
        raise


# ---------------------------------------------------------------------
# Mock responses -- offline-safe demo, same pattern as the fintech demo.
# Keyed by ROLE (what nodes actually call with), and for the two roles
# that decide routing, branched on the input text so the two sample
# cases in main.py genuinely take different paths.
# ---------------------------------------------------------------------
def _mock_chat_response(role: str, user_prompt: str) -> str:
    low_stakes = "csv" in user_prompt.lower() or "export" in user_prompt.lower()

    if role == "intent_classifier":
        if low_stakes:
            return json.dumps({"intent": "feature_question", "entities": {}, "sentiment": "neutral"})
        return json.dumps({
            "intent": "billing_dispute",
            "entities": {"invoice_id": "INV-88213", "amount": "$1,240.00"},
            "sentiment": "negative",
        })

    if role == "reply_drafter":
        if low_stakes:
            return json.dumps({
                "draft_reply": "Yes -- go to Reports > Export and choose CSV from the format dropdown.",
                "confidence": 92,
            })
        return json.dumps({
            "draft_reply": "I understand the charge on INV-88213 looks incorrect -- let me look into that for you.",
            "confidence": 38,
        })

    if role == "severity_tagger":
        return json.dumps({"severity": "high", "reason": "Repeat billing dispute, customer already escalated once"})

    if role == "root_cause_analyst":
        return json.dumps({
            "root_cause": "Duplicate charge caused by a retried webhook after a timeout; the billing system double-posted the invoice.",
        })

    if role == "resolution_drafter":
        return json.dumps({
            "resolution": "Refund the duplicate charge on INV-88213 within 3-5 business days and apply a one-time "
                          "service credit; root cause has been flagged to the billing team to fix the webhook retry logic.",
        })

    return "{}"


def _mock_embedding(text: str) -> list:
    # Deterministic fake vector -- fine for a demo, never used for real similarity math.
    return [float((hash(text) >> i) % 100) / 100 for i in range(16)]
