"""
main.py

Entrypoint. Runs Agent A on two sample messages: one that resolves at
tier 1, one that escalates to Agent B -- so you see both paths, and
the cross-agent handoff, in a single run.

Agent A is the only thing this file ever calls. Agent B only runs
because Agent A's escalate_to_specialist_node decides to call it.
"""
import json

from agents.agent_a_support_triage.graph import app as agent_a_app


def run(customer_message: str, label: str):
    print(f"\n{'=' * 78}\n{label}\n{'=' * 78}")
    result = agent_a_app.invoke({"customer_message": customer_message, "trace": []})

    print("\n--- CROSS-AGENT TRACE ---")
    for line in result["trace"]:
        print(line)

    print("\n--- FINAL STATE ---")
    print(json.dumps({k: v for k, v in result.items() if k != "trace"}, indent=2))


if __name__ == "__main__":
    run(
        "Hi, quick question -- do you support exporting reports to CSV?",
        "CASE 1 -- expected to resolve at Tier 1 (Agent A only)",
    )
    run(
        "I was charged $1,240 TWICE on invoice INV-88213 and nobody has fixed this "
        "after two emails. This is unacceptable.",
        "CASE 2 -- expected to escalate to Agent B",
    )
