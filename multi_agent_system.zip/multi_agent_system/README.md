# Multi-Agent Support Escalation

Two independent LangGraph agents, each internally multi-node and
multi-model, where **Agent A calls Agent B directly** — no third
orchestrator graph.

## Architecture

```
multi_agent_system/
├── config/
│   └── model_registry.py        # role -> internal registry model (edit this to swap models)
├── gateway/
│   └── llm_client.py            # one HTTP client, shared by every node in both agents
├── agents/
│   ├── agent_a_support_triage/       # Agent A
│   │   ├── state.py                  #   SupportState
│   │   ├── nodes.py                  #   3 nodes + the direct call into Agent B
│   │   └── graph.py                  #   Agent A's compiled StateGraph
│   └── agent_b_specialist_escalation/ # Agent B
│       ├── state.py                  #   EscalationState (its own, unrelated to Agent A's)
│       ├── nodes.py                  #   3 nodes
│       └── graph.py                  #   Agent B's compiled StateGraph
├── main.py                      # entrypoint — runs Agent A on 2 sample cases
├── requirements.txt
└── .env.example
```

## The two agents

**Agent A — Tier-1 Support Triage** (`agents/agent_a_support_triage/`)
| Node | Role | Model |
|---|---|---|
| `classify_intent` | `intent_classifier` | `mistral-small-2506-ITG` |
| `retrieve_kb` | `kb_retriever` | `bge-large-en-v1.5-ITG` (embedding) |
| `draft_reply` | `reply_drafter` | `qwen3.6-27b` |
| `escalate` *(conditional)* | — | calls **Agent B's compiled graph directly** |
| `resolve` *(conditional)* | — | rule-based, no model call |

**Agent B — Specialist Escalation** (`agents/agent_b_specialist_escalation/`)
| Node | Role | Model |
|---|---|---|
| `tag_severity` | `severity_tagger` | `mistral-small-4-ITG` |
| `root_cause` | `root_cause_analyst` | `gpt-oss-120b-ITG` |
| `draft_resolution` | `resolution_drafter` | `qwen-latest` |

## How the agent-to-agent call works

There's no orchestrator file wiring the two graphs together. Instead,
`agents/agent_a_support_triage/nodes.py` imports Agent B's already-compiled
graph:

```python
from agents.agent_b_specialist_escalation.graph import app as agent_b_app
```

and `escalate_to_specialist_node` calls it exactly like any other
Python function, mid-node, inside Agent A's own graph:

```python
result = agent_b_app.invoke(agent_b_input)
```

Agent A decides *whether* to escalate (`route_after_draft`, a
conditional edge keyed on confidence + sentiment) and *when* to hand
off (the `escalate` node). Agent B has no knowledge Agent A exists —
it just takes an `EscalationState` in and returns one, which is what
keeps the two agents independently buildable and testable.

Every node's `trace` entries carry across both agents into one
combined audit log, because `escalate_to_specialist_node` folds
`agent_b`'s returned trace into Agent A's own `trace` list.

## Running it

```bash
pip install -r requirements.txt
python main.py
```

Runs fully offline by default (`USE_MOCK_LLM=true` in
`config/model_registry.py`) — Case 1 resolves at Tier 1, Case 2
escalates to Agent B, so you see both paths in one run.

To point at your real internal gateway: copy `.env.example` to `.env`,
fill in each model's `base_url`/`api_key`, set `USE_MOCK_LLM=false`,
and load the `.env` file before running (e.g. `python-dotenv`, or your
shell's own env loading).

## Extending it

- **Add a model from your registry**: add an entry to `MODEL_REGISTRY`
  in `config/model_registry.py`, then point a role at it in
  `ROLE_MODEL_MAP` — no changes needed in `agents/`.
- **Add a third agent**: build it exactly like Agent B (own
  `state.py`/`nodes.py`/`graph.py`, own compiled `app`), then call it
  directly from wherever the handoff should happen — either from
  inside Agent A or Agent B, same pattern as `escalate_to_specialist_node`.
- **Run Agent B standalone** (useful for testing it in isolation):
  `from agents.agent_b_specialist_escalation.graph import app; app.invoke({...})`
