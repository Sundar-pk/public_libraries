"""
model_registry.py

Central map of the internal models your org's registry exposes (from
the "For Chats and Agents" and "For Codebase Indexing and Embeddings"
sections). Nodes never hardcode a base_url/model/api_key triple --
they ask for a *role* ("intent_classifier", "root_cause_analyst", ...)
and this file decides which registry model currently serves that role.
Re-pointing a role at a different model is a one-line change here,
with zero changes inside agents/.
"""
import os

# ---------------------------------------------------------------------
# Every model wired up for this demo, as an OpenAI-compatible endpoint.
# Add the rest of your registry (gpt-oss-120b-ITG is here; mistral-ocr-*,
# gemma-4-31b-ITG, qwen3.6-35b-a3b, qwen3-coder-next, qwen3-embedding-8b,
# bge-m3-ITG, multilingual-e5-large-ITG, etc. all follow the same shape)
# the same way as you wire up more roles.
# ---------------------------------------------------------------------
MODEL_REGISTRY = {
    "gpt-oss-120b-ITG": {
        "base_url": os.environ.get("GPT_OSS_120B_BASE_URL", "https://internal-llm-gw/gpt-oss-120b-itg/v1"),
        "api_key": os.environ.get("GPT_OSS_120B_API_KEY", "dummy-key"),
    },
    "mistral-small-2506-ITG": {
        "base_url": os.environ.get("MISTRAL_SMALL_2506_BASE_URL", "https://internal-llm-gw/mistral-small-2506-itg/v1"),
        "api_key": os.environ.get("MISTRAL_SMALL_2506_API_KEY", "dummy-key"),
    },
    "mistral-small-4-ITG": {
        "base_url": os.environ.get("MISTRAL_SMALL_4_BASE_URL", "https://internal-llm-gw/mistral-small-4-itg/v1"),
        "api_key": os.environ.get("MISTRAL_SMALL_4_API_KEY", "dummy-key"),
    },
    "qwen3.6-27b": {
        "base_url": os.environ.get("QWEN3_6_27B_BASE_URL", "https://internal-llm-gw/qwen3.6-27b/v1"),
        "api_key": os.environ.get("QWEN3_6_27B_API_KEY", "dummy-key"),
    },
    "qwen-latest": {
        "base_url": os.environ.get("QWEN_LATEST_BASE_URL", "https://internal-llm-gw/qwen-latest/v1"),
        "api_key": os.environ.get("QWEN_LATEST_API_KEY", "dummy-key"),
    },
    "bge-large-en-v1.5-ITG": {
        "base_url": os.environ.get("BGE_LARGE_BASE_URL", "https://internal-llm-gw/bge-large-en-v1.5-itg/v1"),
        "api_key": os.environ.get("BGE_LARGE_API_KEY", "dummy-key"),
        "kind": "embedding",
    },
}

# ---------------------------------------------------------------------
# Role -> model. This is the one place that decides which real model
# backs each logical job. Nodes only ever ask for the role.
# ---------------------------------------------------------------------
ROLE_MODEL_MAP = {
    # Agent A -- Tier-1 Support Triage
    "intent_classifier": "mistral-small-2506-ITG",
    "kb_retriever": "bge-large-en-v1.5-ITG",   # embedding model
    "reply_drafter": "qwen3.6-27b",
    # Agent B -- Specialist Escalation
    "severity_tagger": "mistral-small-4-ITG",
    "root_cause_analyst": "gpt-oss-120b-ITG",
    "resolution_drafter": "qwen-latest",
}

# Runs fully offline with canned responses by default -- flip to "false"
# once you've confirmed the real internal endpoints are reachable.
USE_MOCK_LLM = os.environ.get("USE_MOCK_LLM", "true").lower() == "true"


def resolve(role: str) -> dict:
    """Return the registry entry (base_url/api_key/model id) currently
    serving `role`. Raises KeyError with a clear message if the role or
    its mapped model isn't registered -- fail loud, not silently."""
    if role not in ROLE_MODEL_MAP:
        raise KeyError(f"No model mapped for role '{role}' -- add it to ROLE_MODEL_MAP.")
    model_id = ROLE_MODEL_MAP[role]
    if model_id not in MODEL_REGISTRY:
        raise KeyError(f"Role '{role}' maps to '{model_id}', which isn't in MODEL_REGISTRY.")
    return {"model_id": model_id, **MODEL_REGISTRY[model_id]}
