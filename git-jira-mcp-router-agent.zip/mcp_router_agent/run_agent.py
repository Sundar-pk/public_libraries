"""
run_agent.py

CLI for the Git/Jira MCP router agent.

Usage:
    python run_agent.py
    python run_agent.py --query "What are the recent commits in payments-service?"
"""
import argparse
import asyncio

from agent.router_agent import answer_query

SAMPLE_QUERIES = [
    "What are the recent commits in the payments-service repo?",
    "Show me the README for the onboarding-api repo",
    "What is the status of issue OPS-101?",
    "Search Jira issues about onboarding risk",
]


async def run_once(query: str):
    result = await answer_query(query)
    print(f"\n{result}\n")


async def repl():
    print("Git/Jira MCP router agent — interactive demo")
    print("Try, for example:")
    for q in SAMPLE_QUERIES:
        print(f"  \u2022 {q}")
    print("\nType a query, or 'quit' to exit.\n")

    while True:
        try:
            query = input("> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if query.lower() in {"quit", "exit"}:
            break
        if not query:
            continue
        await run_once(query)


def main():
    parser = argparse.ArgumentParser(description="Git/Jira MCP router agent")
    parser.add_argument("--query", help="Run a single query and exit")
    args = parser.parse_args()

    if args.query:
        asyncio.run(run_once(args.query))
    else:
        asyncio.run(repl())


if __name__ == "__main__":
    main()
