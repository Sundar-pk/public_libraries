"""
servers/git_mcp_server.py

A minimal, real MCP server (using the official `mcp` SDK's FastMCP) exposing
two Git-flavored tools. Stands in for wherever your organization actually
hosts a Git MCP server — the agent doesn't care that this one is mock data,
only that it speaks the real MCP protocol over streamable HTTP with bearer
token auth, which it does.

Run standalone:
    GIT_MCP_TOKEN=secret-git-token python servers/git_mcp_server.py
"""
import os

from starlette.applications import Starlette
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse

from mcp.server.fastmcp import FastMCP

EXPECTED_TOKEN = os.environ.get("GIT_MCP_TOKEN", "dev-git-token")
PORT = int(os.environ.get("GIT_MCP_PORT", "8801"))

mcp_server = FastMCP("git-mcp", host="127.0.0.1", port=PORT, stateless_http=True)

# Fake repo data — no real Git access, deliberately, same spirit as the
# mock trade/limit/onboarding data used elsewhere in this workshop.
_COMMITS = {
    "payments-service": [
        {"sha": "a1b2c3d", "author": "j.doe", "message": "Fix retry backoff on gateway timeout"},
        {"sha": "e4f5a6b", "author": "m.lee", "message": "Add idempotency key to POST /charge"},
    ],
    "onboarding-api": [
        {"sha": "9f8e7d6", "author": "r.patel", "message": "Bump risk-score threshold to config"},
    ],
}

_FILES = {
    ("payments-service", "README.md"): "# payments-service\n\nHandles outbound payment capture and retries.",
    ("onboarding-api", "README.md"): "# onboarding-api\n\nKYC/onboarding status and document checklist service.",
}


@mcp_server.tool()
def list_commits(repo: str, limit: int = 5) -> dict:
    """List recent commits for a repository."""
    commits = _COMMITS.get(repo)
    if commits is None:
        return {"error": f"Unknown repo '{repo}'. Known repos: {list(_COMMITS)}"}
    return {"repo": repo, "commits": commits[:limit]}


@mcp_server.tool()
def get_file_contents(repo: str, path: str) -> dict:
    """Get the contents of a file from a repository."""
    content = _FILES.get((repo, path))
    if content is None:
        return {"error": f"No file '{path}' found in repo '{repo}'"}
    return {"repo": repo, "path": path, "content": content}


class BearerTokenMiddleware(BaseHTTPMiddleware):
    """The same shape of gate as any real internal MCP gateway: reject
    anything without the right Authorization: Bearer <token> header before
    it ever reaches a tool."""

    async def dispatch(self, request, call_next):
        auth = request.headers.get("authorization", "")
        if auth != f"Bearer {EXPECTED_TOKEN}":
            return JSONResponse({"error": "unauthorized"}, status_code=401)
        return await call_next(request)


def build_app() -> Starlette:
    app = mcp_server.streamable_http_app()
    app.add_middleware(BearerTokenMiddleware)
    return app


if __name__ == "__main__":
    import uvicorn

    print(f"Git MCP server listening on http://127.0.0.1:{PORT}/mcp (token required)")
    uvicorn.run(build_app(), host="127.0.0.1", port=PORT, log_level="warning")
