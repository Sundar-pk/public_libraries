"""
servers/jira_mcp_server.py

Same pattern as git_mcp_server.py, exposing two Jira-flavored tools.

Run standalone:
    JIRA_MCP_TOKEN=secret-jira-token python servers/jira_mcp_server.py
"""
import os

from starlette.applications import Starlette
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse

from mcp.server.fastmcp import FastMCP

EXPECTED_TOKEN = os.environ.get("JIRA_MCP_TOKEN", "dev-jira-token")
PORT = int(os.environ.get("JIRA_MCP_PORT", "8802"))

mcp_server = FastMCP("jira-mcp", host="127.0.0.1", port=PORT, stateless_http=True)

_ISSUES = {
    "OPS-101": {"key": "OPS-101", "summary": "Payment retries exceeding SLA", "status": "In Progress", "assignee": "j.doe"},
    "OPS-102": {"key": "OPS-102", "summary": "Onboarding risk threshold misconfigured", "status": "Open", "assignee": "r.patel"},
}


@mcp_server.tool()
def get_issue(issue_key: str) -> dict:
    """Get details for a single Jira issue by key, e.g. OPS-101."""
    issue = _ISSUES.get(issue_key.upper())
    if not issue:
        return {"error": f"No issue found with key '{issue_key}'"}
    return issue


@mcp_server.tool()
def search_issues(query: str) -> dict:
    """Search issues by a keyword in their summary."""
    matches = [i for i in _ISSUES.values() if query.lower() in i["summary"].lower()]
    return {"query": query, "matches": matches}


class BearerTokenMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        auth = request.headers.get("authorization", "")
        if auth != f"Bearer {EXPECTED_TOKEN}":
            return JSONResponse({"error": "unauthorized"}, status_code=401)
        return await call_next(request)


def build_app() -> Starlette:
    app = mcp_server.streamable_http_app()
    app.add_middleware(BearerTokenMiddleware)
    return app


if __name__ == "__main__":
    import uvicorn

    print(f"Jira MCP server listening on http://127.0.0.1:{PORT}/mcp (token required)")
    uvicorn.run(build_app(), host="127.0.0.1", port=PORT, log_level="warning")
