# Git/Jira MCP Router Agent

A LangGraph agent that routes a user query to the right MCP tool server —
**Git** or **Jira**, each reachable at its own URL with its own access
token — and answers using an internally-hosted model (GPT-OSS-120B, or
whatever's behind your gateway) over a direct HTTP call with an API key.

This ties the two halves of the workshop together: MCP (tools/access) and
LangGraph (orchestration), in one small, real, tested example.

## How it's wired

```
User query
    │
    ▼
router (deterministic keyword match: git vs jira vs both vs unknown)
    │
    ├── "git"  → connect to GIT_MCP_URL with GIT_MCP_TOKEN
    ├── "jira" → connect to JIRA_MCP_URL with JIRA_MCP_TOKEN
    └── "both" → connect to both, load both toolsets
    │
    ▼
langgraph.prebuilt.create_react_agent
  (tools loaded from the selected MCP server(s), reasoning done by our
   internal model via ChatOpenAI pointed at INTERNAL_LLM_BASE_URL)
```

Routing is deterministic — the same philosophy as every other router in
this workshop: don't spend a model call deciding something a keyword match
decides for free. Only once the right server is picked does a real
tool-calling ReAct loop take over.

## Setup

```bash
pip install -r requirements.txt
```

Six environment variables — one URL + one token per MCP server, plus the
internal LLM gateway config:

```bash
export GIT_MCP_URL=https://git-mcp.internal.example.com/mcp
export GIT_MCP_TOKEN=...

export JIRA_MCP_URL=https://jira-mcp.internal.example.com/mcp
export JIRA_MCP_TOKEN=...

export INTERNAL_LLM_BASE_URL=https://llm-gateway.internal.example.com
export INTERNAL_LLM_API_KEY=...
export INTERNAL_LLM_MODEL=gpt-oss-120b   # optional, this is the default
```

Before presenting, sanity-check all three endpoints:
```bash
python check_setup.py
```

## Running it

```bash
python run_agent.py
python run_agent.py --query "What are the recent commits in payments-service?"
```

## The example MCP servers included here

`servers/git_mcp_server.py` and `servers/jira_mcp_server.py` are small,
**real** MCP servers (built on the official `mcp` SDK, speaking actual
streamable-HTTP MCP with bearer-token auth) backed by mock data — useful
for trying this out before pointing it at your organization's real Git and
Jira MCP servers. Run them locally:

```bash
GIT_MCP_TOKEN=dev-git-token python servers/git_mcp_server.py    # port 8801
JIRA_MCP_TOKEN=dev-jira-token python servers/jira_mcp_server.py  # port 8802
```
Then point `GIT_MCP_URL` / `JIRA_MCP_URL` at `http://127.0.0.1:8801/mcp` and
`http://127.0.0.1:8802/mcp` with the matching tokens above.

**Swapping to your organization's real Git/Jira MCP servers requires no
code changes** — just different URLs and tokens in the environment.

## Sample queries

| Query | Routes to | Tool called |
|---|---|---|
| "What are the recent commits in the payments-service repo?" | git | `list_commits` |
| "Show me the README for the onboarding-api repo" | git | `get_file_contents` |
| "What is the status of issue OPS-101?" | jira | `get_issue` |
| "Search Jira issues about onboarding risk" | jira | `search_issues` |
| "What's the weather today?" | unknown | (no tool call — clarification message) |

## On the internal-model client choice

Every other agent in this workshop used a small hand-rolled `requests`
client for the internal model, since those agents only needed plain-text
reasoning. This one uses `ChatOpenAI(base_url=..., api_key=...)` from
`langchain-openai` instead — still 100% HTTP calls with an API key to our
internal gateway, just through LangChain's well-tested client rather than
a bespoke one. The reason: real MCP tool-calling needs a model client that
implements structured function-calling (binding tool schemas, parsing
`tool_calls` out of responses), and that wire protocol is exactly what
`ChatOpenAI` already does correctly — hand-rolling it here would just be
reinventing something solved, with more room for bugs. See
`agent/router_agent.py:build_internal_llm()` for the one place this
decision lives.

## What's actually been tested

Everything in this repo was verified against **real, running MCP
servers** (not just unit-level logic) before being handed over: bearer
token acceptance and rejection, tool discovery, individual tool calls via
the raw `mcp` SDK, tool loading via `MultiServerMCPClient`, and the full
router → MCP connect → ReAct tool-calling loop end to end for both Git and
Jira queries. The internal LLM gateway itself was validated against a mock
OpenAI-compatible tool-calling server, for the same reason as the other
repos in this workshop: real internal-gateway access isn't available from
where this was built, so the wiring is proven as far as it can be without
your actual endpoint.
