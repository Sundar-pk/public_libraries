"""
check_setup.py

Run this BEFORE presenting to confirm all three real endpoints are
reachable — the internal LLM gateway, the Git MCP server, and the Jira MCP
server — rather than finding out live on stage.

Usage:
    export INTERNAL_LLM_BASE_URL=... INTERNAL_LLM_API_KEY=...
    export GIT_MCP_URL=... GIT_MCP_TOKEN=...
    export JIRA_MCP_URL=... JIRA_MCP_TOKEN=...
    python check_setup.py
"""
import asyncio
import os
import sys

from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_openai import ChatOpenAI


def check_env_vars():
    required = [
        "INTERNAL_LLM_BASE_URL", "INTERNAL_LLM_API_KEY",
        "GIT_MCP_URL", "GIT_MCP_TOKEN",
        "JIRA_MCP_URL", "JIRA_MCP_TOKEN",
    ]
    missing = [v for v in required if not os.environ.get(v)]
    if missing:
        print(f"\u274c  Missing environment variables: {', '.join(missing)}")
        sys.exit(1)
    print("\u2705  All required environment variables are set.")


async def check_llm():
    print("\nChecking internal LLM gateway...")
    try:
        llm = ChatOpenAI(
            base_url=os.environ["INTERNAL_LLM_BASE_URL"],
            api_key=os.environ["INTERNAL_LLM_API_KEY"],
            model=os.environ.get("INTERNAL_LLM_MODEL", "gpt-oss-120b"),
        )
        result = await llm.ainvoke("Reply with the single word OK")
        print(f"\u2705  LLM gateway responded: {result.content.strip()[:100]}")
    except Exception as exc:
        print(f"\u274c  Could not reach the LLM gateway: {exc}")
        sys.exit(1)


async def check_mcp_server(name: str, url_var: str, token_var: str):
    print(f"\nChecking {name} MCP server...")
    try:
        client = MultiServerMCPClient({
            name: {
                "transport": "streamable_http",
                "url": os.environ[url_var],
                "headers": {"Authorization": f"Bearer {os.environ[token_var]}"},
            }
        })
        tools = await client.get_tools(server_name=name)
        print(f"\u2705  {name} MCP server responded with {len(tools)} tool(s): {[t.name for t in tools]}")
    except Exception as exc:
        print(f"\u274c  Could not reach the {name} MCP server: {exc}")
        sys.exit(1)


async def main():
    check_env_vars()
    await check_llm()
    await check_mcp_server("git", "GIT_MCP_URL", "GIT_MCP_TOKEN")
    await check_mcp_server("jira", "JIRA_MCP_URL", "JIRA_MCP_TOKEN")
    print("\nAll three endpoints are reachable \u2014 safe to run the demo.")


if __name__ == "__main__":
    asyncio.run(main())
