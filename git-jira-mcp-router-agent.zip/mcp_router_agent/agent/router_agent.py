"""
agent/router_agent.py

A LangGraph agent that routes a user query to the right MCP tool server —
Git or Jira, each reachable at its own URL with its own access token — and
answers using our internally-hosted model over a direct HTTP call with an
API key, exactly like the other agents in this workshop.

Routing is deterministic (keyword-based) first, same philosophy as every
other router built in this workshop: don't spend an LLM call deciding
something a keyword match can decide for free. Once the right server is
picked, a real LangGraph ReAct agent (langgraph.prebuilt.create_react_agent)
does the tool-calling loop against that server's real MCP tools.

Required environment variables — one URL + one token PER tool server,
since that's how real internal MCP gateways are usually set up (separate
services, separate credentials):

    GIT_MCP_URL, GIT_MCP_TOKEN
    JIRA_MCP_URL, JIRA_MCP_TOKEN
    INTERNAL_LLM_BASE_URL, INTERNAL_LLM_API_KEY
    INTERNAL_LLM_MODEL   (optional, defaults to gpt-oss-120b)
"""
import os
import re

from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_openai import ChatOpenAI
from langgraph.prebuilt import create_react_agent

GIT_KEYWORDS = re.compile(r"\b(commit|repo|repository|branch|file|readme|pull request|pr)\b", re.IGNORECASE)
JIRA_KEYWORDS = re.compile(r"\b(issue|ticket|jira|bug|story|sprint)\b", re.IGNORECASE)


def _server_config():
    """One URL + one access token per MCP tool server — read once, not
    hardcoded, so swapping environments (staging vs prod Git/Jira) never
    touches this file."""
    return {
        "git": {
            "transport": "streamable_http",
            "url": os.environ["GIT_MCP_URL"],
            "headers": {"Authorization": f"Bearer {os.environ['GIT_MCP_TOKEN']}"},
        },
        "jira": {
            "transport": "streamable_http",
            "url": os.environ["JIRA_MCP_URL"],
            "headers": {"Authorization": f"Bearer {os.environ['JIRA_MCP_TOKEN']}"},
        },
    }


def route_query(query: str) -> str:
    """Deterministic router: which MCP server does this query belong to?
    Returns 'git', 'jira', or 'both' if it plausibly needs either/both."""
    is_git = bool(GIT_KEYWORDS.search(query))
    is_jira = bool(JIRA_KEYWORDS.search(query))
    if is_git and is_jira:
        return "both"
    if is_git:
        return "git"
    if is_jira:
        return "jira"
    return "unknown"


def build_internal_llm() -> ChatOpenAI:
    """
    Our internally-hosted model, reached over a direct HTTP call with an
    API key — via LangChain's own OpenAI-compatible client pointed at our
    gateway's base_url, rather than a hand-rolled HTTP client.

    This is a deliberate choice worth being explicit about: real MCP
    tool-calling needs a model client that implements structured
    function-calling (binding tool schemas, parsing tool_calls out of the
    response) — reinventing that wire protocol by hand would just be
    reimplementing what ChatOpenAI already does robustly. It's still 100%
    "HTTP calls + API key to our internal model" — just going through a
    well-tested client instead of a bespoke one, since this scenario
    actually needs real structured tool-calling.
    """
    base_url = os.environ["INTERNAL_LLM_BASE_URL"]
    api_key = os.environ["INTERNAL_LLM_API_KEY"]
    model = os.environ.get("INTERNAL_LLM_MODEL", "gpt-oss-120b")
    return ChatOpenAI(base_url=base_url, api_key=api_key, model=model, temperature=0)


async def answer_query(query: str) -> str:
    """Routes the query, connects to the right MCP server(s) with their own
    credentials, and answers using a real LangGraph ReAct agent over the
    loaded tools."""
    intent = route_query(query)
    print(f"[router] intent = {intent}")

    if intent == "unknown":
        return "I'm not sure whether this is a Git question or a Jira question \u2014 try mentioning a repo/commit or an issue/ticket."

    client = MultiServerMCPClient(_server_config())

    if intent == "both":
        tools = await client.get_tools(server_name="git") + await client.get_tools(server_name="jira")
    else:
        tools = await client.get_tools(server_name=intent)

    llm = build_internal_llm()
    agent = create_react_agent(llm, tools)

    result = await agent.ainvoke({"messages": [{"role": "user", "content": query}]})
    final_message = result["messages"][-1]
    return final_message.content
