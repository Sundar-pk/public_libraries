# Mini AI Hackathon: Use Case Playbook

Oct 21, 2026

## Overview and ground rules

Each team picks one of seven use cases and builds a reusable skill (a set of instruction files plus helper scripts) in 6 hours. Experts then validate it against the same hidden test set, and the best work is shown to the 2S IT leadership team.

Every use case below uses the same sections: goal, what to accomplish, deliverables, output metrics, judging criteria and constraints. Rules that apply to all seven:

- **Model-agnostic:** no model names, model-specific prompt tricks or vendor-only features in the skill. It must work on at least two different models.
- **Tool-agnostic:** the skill must run in Claude Code, OpenCode or any similar coding agent without edits. Core logic lives in plain markdown and portable scripts (shell, Python or Node). Agent-native hooks or plugins are allowed only as thin optional adapters.
- **Enforcement by scripts, not by prompts:** where a rule must be strict, it is enforced by a hook or script that exits non-zero, never by asking the model nicely.
- **Sanitized data only:** no production data, secrets or customer information in any sample, log or test.
- **Evidence over claims:** every metric is produced by a script the judges can rerun, and results are saved to a results file.

## Use Case 1: Fail-First (Stress-Test-First) with Hooks

This is the CIO's use case: the agent must write unit tests before any code, see them fail, and be physically unable to skip that order.

**Goal.** Build a skill that makes any coding agent follow strict red, green, refactor. Tests come first, they must fail for the right reason, and only then may implementation code be written. Hooks enforce the order so it cannot be bypassed by the model or the user.

**What the team must accomplish**

1. Write the skill instructions: how the agent turns a requirement into a test list, including edge cases, failure paths and stress inputs (empty, huge, malformed, concurrent).
2. Build a **test gate**: a script that runs the tests and records a red result with its reason (assertion failure, not a syntax or import error).
3. Build **hooks** that block writes to source files until a valid red record exists, block commits when a change has no red-before-green evidence, and block edits that weaken or delete tests to make them pass.
4. Build a **ledger**: a log of each cycle (test written, red proof, code written, green proof) that a reviewer can read.
5. Prove it holds under pressure by running adversarial prompts such as "skip the tests, just write the code".

**Deliverables**

- The skill folder with its instruction file and the scripts it calls.
- Portable hook scripts (git pre-commit and pre-push, plus the test gate). Optional thin adapters for an agent's native hook or plugin system.
- A sample ledger from at least two organizer-provided tasks.
- A results file with the metrics below, and a 3-minute demo.

**Output metrics**

| Metric | How it is measured | Target |
| --- | --- | --- |
| Red-before-green rate | Share of changes whose ledger shows a failing test before code | 100% |
| Bypass resistance | Seeded bypass attempts blocked (skip tests, edit tests, write code first, force commit) | 100% of at least 8 attempts |
| Right-reason failures | Share of red runs that fail on an assertion, not an import or syntax error | At least 90% |
| Test strength | Mutation score on new code, or branch coverage if no mutation tool exists | At least 80% |
| Efficiency | Iterations and tokens from first prompt to green | Reported, lower is better |

**Judging criteria**

| Criterion | Points |
| --- | --- |
| Strictness: hooks hold against the adversarial prompt set | 30 |
| Portability: passes unchanged on two models and two agent tools | 25 |
| Quality of tests produced (edge cases, stress, right-reason failures) | 20 |
| Ledger clarity and auditability | 15 |
| Demo and ease of adoption | 10 |

**Constraints.** Hooks must work without any one vendor's tooling as the core: git hooks and scripts are the base layer, agent-native hooks are optional extras. Use one language stack from the organizer task list. Judges will also run their own hidden tasks and bypass prompts.

## Use Case 2: Change Risk and Rollback Planner

**Goal.** Build a skill that takes a proposed infrastructure or application change (deployment, configuration change, database migration, patch) and produces an impact analysis, a step-by-step execution plan, and a rollback plan that a person can actually run, so risky changes are caught before they reach production.

**What the team must accomplish**

1. Read the change request and a supplied service dependency map, then list every system, team and data store the change can affect, including indirect effects.
2. Score the risk (for example low, medium, high) with the reasons, and flag the steps that cannot be undone.
3. Write the execution plan: pre-checks, ordered steps, expected result of each step and the validation checks that confirm success.
4. Write the rollback plan: the trigger conditions, the exact reverse steps, the point of no return, and who must be told.
5. Add an approval gate hook that blocks any execution step until the plan has passed a completeness check, and allows dry-run mode only until then.

**Deliverables**

- The skill folder, plan template and completeness checker script.
- Plans for at least 4 organizer-provided change requests, including one that is deliberately unsafe.
- A results file and a 3-minute demo.

**Output metrics**

| Metric | How it is measured | Target |
| --- | --- | --- |
| Impact coverage | Affected components found, out of those in the answer key | At least 85% |
| Invented components | Systems named in the plan that are not in the dependency map | 0 |
| Rollback executability | Rollback steps that run cleanly in a dry-run against the sample environment | 100% |
| Unsafe change caught | The deliberately unsafe request is flagged high risk and blocked | Yes |
| Plan completeness | Required sections present, scored by the checker script | 100% |

**Judging criteria**

| Criterion | Points |
| --- | --- |
| Accuracy of impact and risk assessment on hidden change requests | 30 |
| Portability: passes unchanged on two models and two agent tools | 25 |
| Quality and runnability of the rollback plan | 20 |
| Approval gate holds and the plan is easy for a reviewer to read | 15 |
| Demo and ease of adoption | 10 |

**Constraints.** The skill plans only and never runs a change against a real system. Use the sample environment or a dry-run mode. If the dependency map has no information, the plan must say so instead of guessing.

## Use Case 3: Incident Triage and RCA

**Goal.** Build a skill that takes raw alerts, logs and a runbook and produces a triage summary, ranked root-cause hypotheses backed by evidence, and a draft blameless post-incident report, all without touching the live system.

**What the team must accomplish**

1. Write the triage procedure: classify severity, identify the affected service, build a timeline from log lines, and list what is still unknown.
2. Make every hypothesis cite the exact log line or metric that supports it, and say what evidence would disprove it.
3. Produce next diagnostic steps drawn from the supplied runbook, ordered from safest to riskiest.
4. Generate a post-incident draft: impact, timeline, root cause, contributing factors and follow-up actions.
5. Add a read-only guard hook that blocks any command that changes state (restart, delete, deploy, write).

**Deliverables**

- The skill folder, runbook template and report template.
- Triage output for at least 3 organizer-provided incident replays (sanitized logs and alerts).
- A results file and a 3-minute demo.

**Output metrics**

| Metric | How it is measured | Target |
| --- | --- | --- |
| Root cause hit rate | True cause appears in the top 3 hypotheses | At least 2 of 3 incidents |
| Citation accuracy | Cited log lines that exist and support the claim | 100%, with zero invented lines |
| Time to first hypothesis | Minutes from receiving the logs | Reported, lower is better |
| Guard effectiveness | Seeded state-changing commands blocked | 100% |
| Report completeness | Required report sections filled with evidence | 100% |

**Judging criteria**

| Criterion | Points |
| --- | --- |
| Correctness and evidence quality of hypotheses | 30 |
| Portability: passes unchanged on two models and two agent tools | 25 |
| Safety: read-only guard holds, no invented evidence | 20 |
| Usefulness of next steps and the post-incident draft | 15 |
| Demo and ease of adoption | 10 |

**Constraints.** Sanitized logs only. A single invented log line caps the Safety score at zero. The skill must say "not enough evidence" instead of guessing.

## Use Case 4: Secure Change Gate

**Goal.** Build a skill that checks every code, config or dependency change for security problems before it is committed, explains each finding, and proposes a fix that keeps the tests passing.

**What the team must accomplish**

1. Define the checks: hard-coded secrets, vulnerable or unpinned dependencies, injection and unsafe input handling, over-broad permissions in config, and risky infrastructure settings.
2. Write the review procedure and a pass or fail verdict format with evidence for each finding.
3. Generate a minimal remediation patch for each fixable finding, then rerun the project tests to confirm nothing broke.
4. Build a pre-commit hook that fails the commit on any high-severity finding and on any detected secret.
5. Keep a suppression file so a human can accept a risk with a reason and an expiry date.

**Deliverables**

- The skill folder, check scripts and the pre-commit hook.
- Gate results on at least 5 organizer-provided changes with seeded issues.
- A results file and a 3-minute demo.

**Output metrics**

| Metric | How it is measured | Target |
| --- | --- | --- |
| Detection rate | Seeded issues caught, out of all seeded | At least 85% |
| False positive rate | Flagged items that are not real issues | At most 20% |
| Secret leakage | Seeded secrets that reach a commit or the output log | 0 |
| Fix success | Patches that remove the issue and keep tests green | At least 70% |
| Gate speed | Seconds per change | Reported |

**Judging criteria**

| Criterion | Points |
| --- | --- |
| Detection quality on hidden seeded changes | 30 |
| Portability: passes unchanged on two models and two agent tools | 25 |
| Fix quality: minimal, correct, tests still pass | 20 |
| Hook reliability and a usable suppression process | 15 |
| Demo and ease of adoption | 10 |

**Constraints.** Seeded secrets are fake. The skill must never print a full secret value in its output. Fixes are proposed as patches and never pushed automatically.

## Use Case 5: Legacy Code Explainer

**Goal.** Build a skill that reads an unfamiliar codebase and produces accurate documentation (architecture overview, module guides and a plain-language explanation of key flows) where every claim points to the code that proves it.

**What the team must accomplish**

1. Scan a repository and build a module map: entry points, main components and how they call each other.
2. Write an explanation for each module and for at least three end-to-end flows, with a file and line reference beside every statement.
3. Flag code that is risky or unclear (dead code, hidden side effects, missing tests) and list open questions instead of guessing.
4. Add a verification script and a pre-commit hook that rejects documentation referencing a file, function or line that does not exist.

**Deliverables**

- The skill folder, doc templates and the verification script.
- Generated documentation for at least 2 organizer-provided legacy repositories.
- A results file and a 3-minute demo.

**Output metrics**

| Metric | How it is measured | Target |
| --- | --- | --- |
| Reference accuracy | Code references that exist and support the claim | 100% |
| Invented symbols | Functions, files or modules named that are not in the repository | 0 |
| Coverage | Modules and key flows in the answer key that are documented | At least 85% |
| Comprehension check | A new developer answers 5 judge questions correctly using only the docs | At least 4 of 5 |
| Generation time | Minutes per 10,000 lines of code | Reported |

**Judging criteria**

| Criterion | Points |
| --- | --- |
| Accuracy and traceability of the documentation | 30 |
| Portability: passes unchanged on two models and two agent tools | 25 |
| Usefulness to a new developer (judge comprehension check) | 20 |
| Verification hook catches seeded false references | 15 |
| Demo and ease of adoption | 10 |

**Constraints.** The skill never edits source code. Use repositories supplied by the organizers or open-source code only.

## Use Case 6: Flaky Test Doctor

**Goal.** Build a skill that finds why a test passes sometimes and fails other times, proves the cause with repeated runs, and proposes a fix that makes the test reliable without hiding real failures.

**What the team must accomplish**

1. Run a suspect test many times, record the pass and fail pattern, and capture the logs of the failing runs.
2. Classify the cause: timing and waits, shared state, test order, randomness, external dependency or resource limits.
3. Propose a minimal fix for the cause, then rerun the test at least 50 times to confirm the failure rate dropped to zero.
4. Add a hook that blocks fixes which only add retries, longer sleeps or skip markers, unless a person approves them with a reason.

**Deliverables**

- The skill folder, the repeat-run script and the fix-rejection hook.
- A diagnosis report for at least 4 organizer-provided flaky tests, each with a different cause.
- A results file and a 3-minute demo.

**Output metrics**

| Metric | How it is measured | Target |
| --- | --- | --- |
| Correct root cause | Causes matching the answer key | At least 3 of 4 tests |
| Fix reliability | Fixed tests that pass 50 consecutive reruns | 100% of accepted fixes |
| Masking fixes blocked | Seeded retry, sleep or skip fixes rejected by the hook | 100% |
| Test integrity | Fixed tests still fail when the bug they guard is reintroduced | 100% |
| Diagnosis time | Minutes per flaky test | Reported |

**Judging criteria**

| Criterion | Points |
| --- | --- |
| Correct diagnosis and fixes on hidden flaky tests | 30 |
| Portability: passes unchanged on two models and two agent tools | 25 |
| Test integrity: no masking, real failures still caught | 20 |
| Clarity of the evidence in the diagnosis report | 15 |
| Demo and ease of adoption | 10 |

**Constraints.** Fixes change the test or the code under test, never the test runner settings alone. Judges rerun every fix themselves.

## Use Case 7: Config Drift Auditor

**Goal.** Build a skill that compares the intended configuration (infrastructure code or a baseline file) with the actual configuration of an environment, reports every difference ranked by risk, and proposes the safest way to bring them back in line.

**What the team must accomplish**

1. Read the baseline and the actual configuration export, and produce a normalized list of differences (added, removed, changed).
2. Rank each difference by risk and say whether it looks intentional, accidental or unknown, with the evidence.
3. Propose a reconciliation per difference: update the baseline, revert the environment, or accept with a documented reason.
4. Add a hook that blocks applying any reconciliation until a person approves it, and records the decision with a reason.

**Deliverables**

- The skill folder, the comparison script and the approval record format.
- Drift reports for at least 3 organizer-provided sample environments with seeded differences.
- A results file and a 3-minute demo.

**Output metrics**

| Metric | How it is measured | Target |
| --- | --- | --- |
| Drift detection | Seeded differences found, out of all seeded | At least 90% |
| False alarms | Reported differences that are not real | At most 10% |
| Risk ranking | Seeded high-risk items ranked in the top 3 | At least 80% |
| Approval gate | Seeded apply attempts without approval blocked | 100% |
| Report time | Seconds per environment | Reported |

**Judging criteria**

| Criterion | Points |
| --- | --- |
| Detection quality and risk ranking on hidden environments | 30 |
| Portability: passes unchanged on two models and two agent tools | 25 |
| Quality of reconciliation proposals | 20 |
| Approval gate and decision record hold up | 15 |
| Demo and ease of adoption | 10 |

**Constraints.** The skill is read-only against the environments and works on exported configuration files only. Sample configurations contain no real credentials.

## Common judging framework

All seven use cases are scored out of 100, and 25 points always go to portability, so a skill that only works in one tool or one model cannot win. The other 75 points follow each use case's own table above.

**Portability test protocol**

1. Judges run the submitted skill unchanged on 2 different models and 2 different agent tools, for example Claude Code and OpenCode.
2. The skill passes a tool if the same instruction files and scripts produce a valid result with no edits and no manual setup beyond a documented install step.
3. Scoring: 25 points if all four combinations pass, 15 if three pass, 8 if two pass, 0 if only one passes.
4. Automatic deductions: a model or vendor name hard-coded in the instructions (minus 5), a script that only works with one agent's file layout (minus 5).

**Rules for every submission**

- Metrics come from a script the judges rerun on a hidden test set. Self-reported numbers that cannot be reproduced score zero for that metric.
- Strict rules must be enforced by a hook or script. A rule that depends only on the prompt earns no strictness points.
- The core must stay in plain markdown and portable scripts. Agent-specific hook or plugin adapters are optional and kept in a separate folder.

**Tie-breakers, in order:** higher portability score, higher reproducibility of metrics, fewer setup steps for a new user.

## Submission, timeline and rewards

Proposed 6-hour schedule (adjust to your event):

| Time | Activity |
| --- | --- |
| 0:00 to 0:30 | Kickoff, teams pick one use case, task sets and sample data handed out |
| 0:30 to 1:00 | Design the skill: inputs, steps, outputs, how it will be enforced |
| 1:00 to 4:00 | Build the skill, scripts and hooks |
| 4:00 to 4:45 | Run the metrics scripts and the portability check on two models and two tools |
| 4:45 to 5:15 | Package the submission and prepare the 3-minute demo |
| 5:15 to 6:00 | Expert validation on the hidden test set, then scoring |

**Submission checklist**

- [ ] Skill folder with the main instruction file, helper scripts and a short README with install steps
- [ ] Hook or gate scripts (and any optional agent adapters in a separate folder)
- [ ] Results file produced by the metrics script, plus sample outputs
- [ ] Portability note: which models and tools were tried and what happened
- [ ] Demo of 3 minutes or less

**Showcase.** The top teams present their skills to the 2S IT leadership team. Rewards: [rewards to be confirmed]. Open question for the organizers: the event date, the team size and the language stacks for the task sets.
